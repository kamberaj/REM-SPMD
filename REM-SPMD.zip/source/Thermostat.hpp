/* 
 * File:   Thermostat.hpp
 * Author: Hiqmet Kamberaj
 *
 * Created on January 6, 2015
 */

#include <vector>
#include "Nosethermo.hpp"

using namespace std;
using namespace nose;

namespace thermo {
   /**
   * @class Thermostat
   * Classical  Particle optimization
   * @note Hiqmet Kamberaj, JCP, 2010, in preparation
   */
    class Thermostat {

    public:
        Thermostat();
        Thermostat(int ndim, double kt, double tau, int m, int i);
        Thermostat(const Thermostat& orig);
        virtual ~Thermostat();
        virtual void refresh();
        
        void setupNoseChains(int ndim, double kt, double tau, int m);
        void setTemperature(double kt);
        double getTemperature();
        void setThermostatParticle(int i);
        int getThermostatParticle();
        double getThermostatEnergy();

        void setThermostatDimension(int i);
        int getThermostatDimension();

        void UpdateThermostatVariables(vector <double> &v, vector <double> mass, double dt);
        
        vector  <Nosethermo*> _Nose;

    private:
        int myParticle;
        int Ndim;
        double KT;
    };
}
