/* 
 * File:   Nosethermo.hpp
 * Author: Hiqmet Kamberaj
 *
 * Created on January 6, 2015
 */

#ifndef Nosethermo_HPP
#define	Nosethermo_HPP

#include <vector>

using namespace std;

namespace nose {
   /**
   * @class Nosethermo
   * Classical  Particle optimization
   * @note Hiqmet Kamberaj, JCP, 2010, in preparation
   */
    class Nosethermo {

    public:
        Nosethermo();
        Nosethermo(double kt, double tau, int m);
        Nosethermo(const Nosethermo& orig);
        virtual ~Nosethermo();
        virtual void refresh();
        
        void updateNoseChainVariables(double dt);
        double update_nhc_respa(double ke, double Dt);
        double update_nhm_respa(double ke, double Dt);

        double getNoseEnergy();
        
        void setNoseChainTemperature(double kt);
        int getNoseChainTemperature();
        

        void initNoseMultipleChains();
        double _MaclaurinSeries(double x);
        
    private:
        int M;
        int Nrespa;
        double Tau;
        double KT;
        vector<double> Vel;
        vector<double> Pos;
        vector<double> G;
        vector<double> Mass;
    };
}

#endif	/* Nosethermo_HPP */

