//
//  TorsionType.cpp
//  
//
//  Created by Hiqmet Kamberaj on 30/06/2015.
//
//

#include "TorsionType.hpp"

#include <iostream>
#include <cmath>
#include <cstring>
#include <vector>
#include "Maths.hpp"

using namespace std;
using namespace maths;


namespace spo {
    TorsionType::TorsionType() {
    }
    TorsionType::TorsionType(int ndim, int I, int J, int K, int L, double theta0, double kforce) {
        for (int i=0; i < ndim; i++) {
            this->forceA.push_back(0.0);
            this->forceB.push_back(0.0);
            this->forceC.push_back(0.0);
            this->forceD.push_back(0.0);
        }
        setTorsionAtomIndexA(I);
        setTorsionAtomIndexB(J);
        setTorsionAtomIndexC(K);
        setTorsionAtomIndexD(L);
        setPhaseTorsion(theta0);
        setTorsionForceConstant(kforce);
    }
    TorsionType::TorsionType(const TorsionType& orig){
    }
    TorsionType::~TorsionType(){
    }
    double TorsionType::getTorsionForceConstant(){
        return this->ktheta;
    }
    void TorsionType::setTorsionForceConstant(double k){
        this->ktheta = k;
    }
    double TorsionType::getPhaseTorsion(){
        return this->delta;
    }
    void TorsionType::setPhaseTorsion(double theta){
        this->delta = theta;
    }
    int TorsionType::getMultiplicity(){
        return this->Mult;
    }
    void TorsionType::setMultiplicity(int m){
        this->Mult = m;
    }

    double TorsionType::getEnergy(){
        return this->e;
    }
    void TorsionType::calcTorsionGradient(double x1[], double x2[], double x3[], double x4[], int dim){
        double r21[dim];
        double r32[dim];
        double r23[dim];
        double r34[dim];
        double r43[dim];
        //
        double u21[dim];
        double u32[dim];
        double u23[dim];
        double u34[dim];
        double u43[dim];
        //
        double mr21;
        double mr32;
        double mr23;
        double mr34;
        double mr43;
        //
        double DT1[dim];
        double DT2[dim];
        double DT3[dim];
        double DT4[dim];
        //
        double r21Xr32[dim];
        double r43Xr32[dim];
        //
        double dtheta1[dim];
        double dtheta2[dim];
        double dtheta4[dim];
        //
        double ctheta, stheta, theta;
        //
        double ctheta123, stheta123, ctheta234, stheta234;
        //
        for (int i=0; i < dim; i++) {
            r21[i] = x1[i] - x2[i];
            r32[i] = x2[i] - x3[i];
            r23[i] = x3[i] - x2[i];
            r43[i] = x3[i] - x4[i];
            r34[i] = x4[i] - x3[i];
        }
        mr21 = sqrt( _dot_product(r21, r21) );
        mr32 = sqrt( _dot_product(r32, r32) );
        mr34 = sqrt( _dot_product(r34, r34) );
        mr43 = mr34;
        mr23 = mr32;
        for (int i=0; i < dim; i++) {
            u21[i] = r21[i]/mr21;
            u32[i] = r32[i]/mr32;
            u23[i] = r23[i]/mr23;
            u34[i] = r34[i]/mr34;
            u43[i] = r43[i]/mr43;
        }
        (void) _calcAngle(u21, u23, dim, ctheta123, stheta123);
        (void) _calcAngle(u32, u34, dim, ctheta234, stheta234);
        if ( abs(stheta123) >= 1.0e-10 && abs(stheta234) >= 1.0e-10 ) {
            double deter = stheta123 * stheta234;
            ctheta = ( ctheta123 * ctheta234 - _dot_product(u21, u43) ) / deter;
            if (abs(ctheta) > 1.0) ctheta = sign(1.0, ctheta);
            theta = acos( ctheta );
            _cross_product( u21, u32, r21Xr32 );
            _cross_product( u43, u32, r43Xr32 );
            deter = stheta123 * stheta234;
            stheta = -_dot_product(u43, r21Xr32) / deter;
    
        
        // Energy contribution
            double A = this->getTorsionForceConstant();
            double dtheta = theta - this->getPhaseTorsion();
            this->e = A * dtheta * dtheta;
        
        // calculate forces
            double term = A * 2.0 * dtheta;
            double dudcos = -term / stheta;
        
            deter = mr21 * stheta123 * stheta123;
            for (int i=0; i < dim; i++) {
                dtheta1[i] = -r21Xr32[i]/deter;
                DT1[i] =  -stheta * dtheta1[i];
            }
            deter = mr43 * stheta234 * stheta234;
            for (int i=0; i < dim; i++) {
                dtheta4[i] = -r43Xr32[i]/deter;
                DT4[i] = -stheta * dtheta4[i];
            }
            double c123 = (mr21 * ctheta123 / mr32) - 1.0;
            double b432 = mr43 * ctheta234 / mr32;
            for (int i=0; i < dim; i++) {
                dtheta2[i] = c123 * dtheta1[i] - b432 * dtheta4[i];
                DT2[i] =  -stheta * dtheta2[i];
                DT3[i] = -(DT1[i] + DT2[i] + DT4[i]);
            }
            for (int i=0; i < dim; i++){
                this->forceA[i] =  dudcos * DT1[i];
                this->forceB[i] =  dudcos * DT2[i];
                this->forceC[i] =  dudcos * DT3[i];
                this->forceD[i] =  dudcos * DT4[i];
            }
        }
    }
    
    vector<double> TorsionType::getTorsionGradientAtomTypeA(){
        return this->forceA;
    }
    vector<double> TorsionType::getTorsionGradientAtomTypeB(){
        return this->forceB;
    }
    vector<double> TorsionType::getTorsionGradientAtomTypeC(){
        return this->forceC;
    }
    vector<double> TorsionType::getTorsionGradientAtomTypeD(){
        return this->forceD;
    }
    
    void TorsionType::setTorsionAtomTypeA(char atype[]){
        strcpy(this->atomTypeA, atype);
    }
    void TorsionType::getTorsionAtomTypeA(char atype[]){
        strcpy(atype, this->atomTypeA);
    }
    
    void TorsionType::setTorsionAtomTypeB(char atype[]){
        strcpy(this->atomTypeB, atype);
    }
    void TorsionType::getTorsionAtomTypeB(char atype[]){
        strcpy(atype, this->atomTypeB);
    }
    
    void TorsionType::setTorsionAtomTypeC(char atype[]){
        strcpy(this->atomTypeC, atype);
    }
    void TorsionType::getTorsionAtomTypeC(char atype[]){
        strcpy(atype, this->atomTypeC);
    }

    void TorsionType::setTorsionAtomTypeD(char atype[]){
        strcpy(this->atomTypeD, atype);
    }
    void TorsionType::getTorsionAtomTypeD(char atype[]){
        strcpy(atype, this->atomTypeD);
    }
    
    void TorsionType::setTorsionAtomIndexA(int i){
        AtomIndexA = i;
    }
    int TorsionType::getTorsionAtomIndexA(){
        return this->AtomIndexA;
    }
    
    void TorsionType::setTorsionAtomIndexB(int i){
        AtomIndexB = i;
    }
    int TorsionType::getTorsionAtomIndexB(){
        return this->AtomIndexB;
    }

    void TorsionType::setTorsionAtomIndexC(int i){
        AtomIndexC = i;
    }
    int TorsionType::getTorsionAtomIndexC(){
        return this->AtomIndexC;
    }

    void TorsionType::setTorsionAtomIndexD(int i){
        AtomIndexD = i;
    }
    int TorsionType::getTorsionAtomIndexD(){
        return this->AtomIndexD;
    }

}

