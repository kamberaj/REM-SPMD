//
//  TorsionType.h
//  
//
//  Created by Hiqmet Kamberaj on 30/06/2015.
//
//

#ifndef ____TorsionType__
#define ____TorsionType__

#include <stdio.h>

#include <vector>

using namespace std;

namespace spo {
    class TorsionType {
    public:
        TorsionType();
        TorsionType(int ndim, int I, int J, int K, int L, double theta0, double kforce);
        TorsionType(const TorsionType& orig);
        virtual ~TorsionType();
        
   
        double getTorsionForceConstant();
        void setTorsionForceConstant(double f);
        double getPhaseTorsion();
        void setPhaseTorsion(double b);
        int getMultiplicity();
        void setMultiplicity(int b);
        double getEnergy();
        
        void calcTorsionGradient(double x1[], double x2[], double x3[], double x4[], int dim);
        vector<double> getTorsionGradientAtomTypeA();
        vector<double> getTorsionGradientAtomTypeB();
        vector<double> getTorsionGradientAtomTypeC();
        vector<double> getTorsionGradientAtomTypeD();
        
        void setTorsionAtomTypeA(char atype[]);
        void setTorsionAtomTypeB(char atype[]);
        void setTorsionAtomTypeC(char atype[]);
        void setTorsionAtomTypeD(char atype[]);
        void getTorsionAtomTypeA(char atype[]);
        void getTorsionAtomTypeB(char atype[]);
        void getTorsionAtomTypeC(char atype[]);
        void getTorsionAtomTypeD(char atype[]);
        
        void setTorsionAtomIndexA(int i);
        int getTorsionAtomIndexA();
        void setTorsionAtomIndexB(int i);
        int getTorsionAtomIndexB();
        void setTorsionAtomIndexC(int i);
        int getTorsionAtomIndexC();
        void setTorsionAtomIndexD(int i);
        int getTorsionAtomIndexD();

        
    private:
        double delta;
        double ktheta;
        double e;
        int Mult;
        vector<double> forceA;
        vector<double> forceB;
        vector<double> forceC;
        vector<double> forceD;
        char atomTypeA[4];
        char atomTypeB[4];
        char atomTypeC[4];
        char atomTypeD[4];
        int AtomIndexA;
        int AtomIndexB;
        int AtomIndexC;
        int AtomIndexD;
    };
    
}

#endif /* defined(____TorsionType__) */
