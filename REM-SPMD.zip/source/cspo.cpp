///////////////////////////////////////////////////////////////////////////////////////////////////
/*
 * Enhanced Molecular Dynamics Simulations using Swarm Particle Intelligence
 *
 * File:   cspo.cpp
 * Author: Hiqmet Kamberaj
 *
 * Created on November 25, 2010, 11:20 AM
 */
///////////////////////////////////////////////////////////////////////////////////////////////////
#include <cstdlib>
#include <cstdio>
#include <iostream>
#include <cmath>
#include <cstring>

#include <sys/time.h>

#include "CSwarm.hpp"
#include "CParticle.hpp"
#include "Maths.hpp"
#include "Random.hpp"
#include "defs.hpp"

#include "VdwTerm.hpp"
#include "BondTerm.hpp"
#include "AngleTerm.hpp"
#include "TorsionTerm.hpp"


using namespace maths;
using namespace std;
using namespace spo;
using namespace rangen;


///////////////////////////////////////////////////////////////////////////////////////////////////
// global variables with their default values
short int qbias= 1;
int Nparticles = 10;
int Nthermos   = 10;
int Ndim       = 12;

double Xmin = -60.0;
double Xmax =  60.0;
double dt   =  0.0005;
int Niter   =  505000;
int Nskip   =  500;
int Nstart  =  5000;
int Nswaps  =  10;

double kt0  =  20.0*Rgas;
double kt   = 420.0*Rgas;

///////////////////////////////////////////////////////////////////////////////////////////////////
// External functions
void SwarmSwap(CSwarm& cswarm);
void inputLogo();
void outputLogo();

///////////////////////////////////////////////////////////////////////////////////////////////////
/*
 *  Main function
 */
///////////////////////////////////////////////////////////////////////////////////////////////////
int main(int argc, char** argv) {
    
    //---- Local variables
    vector<double> x, vel, force, dihe_angles;
    double Score;
    int k, iter, iParticle;
    double temp;
    double ekin,pe;
    struct timeval tvBegin, tvEnd, tvDiff;
    bool qfileStart = true;
    

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
    gettimeofday(&tvBegin, NULL);
    _timeval_print(&tvBegin);

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
    inputLogo();
    if (argc < 2) {
        cout << "Usuage:  dist/Debug/OS/run1 -nreplicas 10 -nthermos 10 -nparticles 4 -niter 10000 -nskip 100 -nstart 5000 -nswaps 10 -tempi 20 -tempf 420 -qbias 1" << endl;
        exit(1);
    }
    else {
        for (int i=1; i<argc-1; i+=2) {
            if ( strcmp(argv[i], "-nreplicas") == 0 ) {
                cout << argv[i] << " " << argv[i+1] << endl;
                Nparticles = atoi(argv[i+1]);
            }
            else if ( strcmp(argv[i], "-nthermos") == 0 ) {
                cout << argv[i] << " " << argv[i+1] << endl;
                Nthermos = atoi(argv[i+1]);
            }
            else if ( strcmp(argv[i], "-nparticles") == 0 ) {
                cout << argv[i] << " " << argv[i+1] << endl;
                Ndim = 3*atoi(argv[i+1]);
            }
            else if ( strcmp(argv[i], "-niter") == 0 ) {
                cout << argv[i] << " " << argv[i+1] << endl;
                Niter = atoi(argv[i+1]);
            }
            else if ( strcmp(argv[i], "-nskip") == 0 ) {
                cout << argv[i] << " " << argv[i+1] << endl;
                Nskip = atoi(argv[i+1]);
            }
            else if ( strcmp(argv[i], "-nstart") == 0 ) {
                cout << argv[i] << " " << argv[i+1] << endl;
                Nstart = atoi(argv[i+1]);
            }
            else if ( strcmp(argv[i], "-nswaps") == 0 ) {
                cout << argv[i] << " " << argv[i+1] << endl;
                Nswaps = atoi(argv[i+1]);
            }
            else if ( strcmp(argv[i], "-tempi") == 0 ) {
                kt0 = Rgas*atof(argv[i+1]);
                cout << kt0 << endl;
            }
            else if ( strcmp(argv[i], "-tempf") == 0 ) {
                kt = Rgas*atof(argv[i+1]);
                cout << kt << endl;
            }
            else if ( strcmp(argv[i], "-qbias") == 0 ) {
                qbias = atoi(argv[i+1]);
                cout << qbias << endl;
            }
       }
        
    }
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// ----> A set of output files
    FILE *file1 = fopen("tempIndex.txt", "w");
    FILE *file2 = fopen("energy.txt", "w");
    FILE *file3 = fopen("traj.pdb", "w");

    
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    double avr_rg[Nparticles];
    double avr_ahel[Nparticles];
    double avr_asph[Nparticles];
    double avr_chirality[Nparticles];
    double avr_rsa[Nparticles];
    
    double avr_bond_pe[Nparticles];
    double avr_angle_pe[Nparticles];
    double avr_torsion_pe[Nparticles];
    double avr_vdw_pe[Nparticles];
    double avr_elec_pe[Nparticles];
 
    double avr_ke[Nparticles];
    double avr_tot_pe[Nparticles];
    double avr_tot_en[Nparticles];
    double avr_ub[Nparticles];
    double avr_tot_pe2[Nparticles];
    double avr_tot_en2[Nparticles];
    double avr_cv[Nparticles];
    double forces[Ndim];
    
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    CSwarm swarm(Nparticles, Ndim, Xmin, Xmax, dt, M, tau, kt0, kt, qbias);
    initrand();
    swarm.setupSwarmGlobalBestPosition();
    for (std::vector<CParticle*>::const_iterator it = swarm._Particle.begin(); it != swarm._Particle.end(); ++it) {
        (*it)->setupLocalBestParticlePosition();
    }
    swarm.initSwarmParticles(mass, qfileStart);
    
    swarm.RandomInitSwarmParticles();
    
    
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// ----  Get Scores and forces at t=0
    k = 0;
    for (std::vector<CParticle*>::const_iterator it = swarm._Particle.begin(); it != swarm._Particle.end(); ++it, ++k) {
        avr_ke[k] = 0.0;
        avr_tot_pe[k] = 0.0;
        avr_tot_en[k] = 0.0;
        avr_ub[k] = 0.0;
        avr_tot_pe2[k] = 0.0;
        avr_tot_en2[k] = 0.0;
        
        avr_rg[k] = 0.0;
        avr_ahel[k] = 0.0;
        avr_asph[k] = 0.0;
        avr_chirality[k] = 0.0;
        avr_rsa[k] = 0.0;
        
        avr_bond_pe[k] = 0.0;
        avr_angle_pe[k] = 0.0;
        avr_torsion_pe[k] = 0.0;
        avr_vdw_pe[k] = 0.0;
        avr_elec_pe[k] = 0.0;
        
        (*it)->setupDihedralAngles();
    }
    for (int i = 0; i < swarm.getSwarmParticleDimension(); i++){
        x.push_back(0.0);
        vel.push_back(0.0);
        force.push_back(0.0);
    }
    
// setup dihedral angles
    int Ndihes = 0;
    for (int i = 0; i < swarm.getSwarmParticleDimension()/3; i+=4){
        dihe_angles.push_back(0.0);
        Ndihes++;
    }
    double avr_DiheAngles[Ndihes];
    for (int i = 0; i < Ndihes; i++) avr_DiheAngles[i] = 0.0;
    
    k=0;
    for (std::vector<CParticle*>::const_iterator it = swarm._Particle.begin(); it != swarm._Particle.end(); ++it, ++k) {
        x = (*it)->getParticlePosition();
        
        // Calculate VDW term
        (*it)->_vdwTerm->calcEnergy(x);
        Score = (*it)->_vdwTerm->getEnergy();
        force = (*it)->_vdwTerm->getForces();
        for (int i = 0; i < Ndim; i++) forces[i] = force[i];

        // Calculate Elec term
        (*it)->_elecTerm->calcEnergy(x);
        Score += (*it)->_elecTerm->getEnergy();
        force = (*it)->_elecTerm->getForces();
        for (int i = 0; i < Ndim; i++) forces[i] += force[i];

        // Calculate Bond Stretching term
        (*it)->_bondTerm->calcEnergy(x);
        Score += (*it)->_bondTerm->getEnergy();
        force  = (*it)->_bondTerm->getForces();
        for (int i = 0; i < Ndim; i++) forces[i] += force[i];

        // Calculate Angle Bending term
        (*it)->_angleTerm->calcEnergy(x);
        Score += (*it)->_angleTerm->getEnergy();
        force  = (*it)->_angleTerm->getForces();
        for (int i = 0; i < Ndim; i++) forces[i] += force[i];

        // Calculate Dihedral angle term
        (*it)->_torsionTerm->calcEnergy(x);
        Score += (*it)->_torsionTerm->getEnergy();
        force  = (*it)->_torsionTerm->getForces();
        for (int i = 0; i < Ndim; i++) forces[i] += force[i];

        (*it)->setParticleScore(Score);
        (*it)->setParticleForce(forces);
        
        
    }
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    cout.width(25);
    cout << "REMARK               ";
    cout.width(25);
    cout << "Replica index:       ";
    cout.width(25);
    cout << "Time (ps):           ";
    cout.width(25);
    cout << "Temperature:         ";
    cout.width(25);
    cout << "Particles momenta:   ";
    cout.width(25);
    cout << "Average Pot. Energy: ";
    cout.width(25);
    cout << "Average tot. Energy: ";
    cout.width(25);
    cout << "Best Pot. Energy:    " << endl;
    fprintf(file3, "TITLE     frame t=%15.3f\n",dt);
    fprintf(file3, "REMARK    THIS IS A PROTEIN FOLDING-UNFOLDING SIMULATION WITH REM\n");

    
// Loop over MD steps
    int Iframes=0;
    for (iter = 0; iter < Niter; ++iter) {
        
        // --- Update thermostats at t+dt/2
        swarm.moveNoseThermostatNextStep();

        // --- Update particle velocities at t+dt/2
        swarm.moveVelocityNextStep();
        
        // --- Update particle positions at t+dt
        swarm.movePositionNextStep();
        
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// ----  Get forces and scores at t+dt
        for (std::vector<CParticle*>::const_iterator it = swarm._Particle.begin(); it != swarm._Particle.end(); ++it) {
            x = (*it)->getParticlePosition();
            
            // Calculate VDW term
            (*it)->_vdwTerm->calcEnergy(x);
            Score = (*it)->_vdwTerm->getEnergy();
            force = (*it)->_vdwTerm->getForces();
            for (int i = 0; i < Ndim; i++) forces[i] = force[i];
            
            // Calculate Elec term
            (*it)->_elecTerm->calcEnergy(x);
            Score += (*it)->_elecTerm->getEnergy();
            force = (*it)->_elecTerm->getForces();
            for (int i = 0; i < Ndim; i++) forces[i] += force[i];

            // Calculate Bond Stretching term
            (*it)->_bondTerm->calcEnergy(x);
            Score += (*it)->_bondTerm->getEnergy();
            force = (*it)->_bondTerm->getForces();
            for (int i = 0; i < Ndim; i++) forces[i] += force[i];
            
            // Calculate Angle Bending term
            (*it)->_angleTerm->calcEnergy(x);
            Score += (*it)->_angleTerm->getEnergy();
            force = (*it)->_angleTerm->getForces();
            for (int i = 0; i < Ndim; i++) forces[i] += force[i];
            
            // Calculate Dihedral angle term
            (*it)->_torsionTerm->calcEnergy(x);
            Score += (*it)->_torsionTerm->getEnergy();
            force = (*it)->_torsionTerm->getForces();
            for (int i = 0; i < Ndim; i++) forces[i] += force[i];
            
            (*it)->setParticleScore(Score);
            (*it)->setParticleForce(forces);
        }
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        // --- Update particle velocities at t+dt
        swarm.moveVelocityNextStep();
        
        // --- Update thermostats at t+dt
        swarm.moveNoseThermostatNextStep();
 
        // ---- Kinetic energy
        if ( iter > Nstart ) {
            k = 0;
            for (std::vector<Thermostat*>::const_iterator it = swarm._Thermo.begin(); it != swarm._Thermo.end(); ++it, ++k) {
                iParticle = (*it)->getThermostatParticle();
                swarm._Particle[iParticle]->calcParticleKineticEnergy();
                
                ekin        = swarm._Particle[iParticle]->getParticleKineticEnergy();
                avr_ke[k]  += ekin;
                pe          = swarm._Particle[iParticle]->getParticleScore();
                
                avr_tot_pe[k]  += pe;
                avr_tot_en[k]  += pe + ekin;
                avr_tot_pe2[k] += pe*pe;
                avr_tot_en2[k] += (pe + ekin)*(pe + ekin);
                avr_ub[k]  += swarm._Particle[iParticle]->getParticleBiasEnergy();
                
                avr_elec_pe[k]    += swarm._Particle[iParticle]->_elecTerm->getEnergy();
                avr_vdw_pe[k]     += swarm._Particle[iParticle]->_vdwTerm->getEnergy();
                avr_bond_pe[k]    += swarm._Particle[iParticle]->_bondTerm->getEnergy();
                avr_angle_pe[k]   += swarm._Particle[iParticle]->_angleTerm->getEnergy();
                avr_torsion_pe[k] += swarm._Particle[iParticle]->_torsionTerm->getEnergy();
                
                swarm._Particle[iParticle]->doGyrationTensorAnalysis();
                avr_rg[k]    += swarm._Particle[iParticle]->getRadiusGyration();
                avr_rsa[k]   += swarm._Particle[iParticle]->getRelativeShapeAnisotropy();
                avr_ahel[k]  += swarm._Particle[iParticle]->getAhelicity();
                avr_asph[k]  += swarm._Particle[iParticle]->getAsphericity();
                
                swarm._Particle[iParticle]->calcChirality();
                avr_chirality[k]  += swarm._Particle[iParticle]->getChirality();
                
                swarm._Particle[iParticle]->calcDihedralAngles();
                dihe_angles = swarm._Particle[iParticle]->getDihedralAngles();
                for (int i = 0; i < Ndihes; i++) avr_DiheAngles[i] += dihe_angles[i];
            }
            if (iter%Nskip == 0) {
                printf("%10d,", iter);
                k = 0;
                for (std::vector<Thermostat*>::const_iterator it = swarm._Thermo.begin(); it != swarm._Thermo.end(); ++it, ++k) {
                    
                    iParticle = (*it)->getThermostatParticle();
                    temp = 2.0*avr_ke[k]/(double) (Nskip*Ndim)/Rgas;
                    vel = swarm._Particle[iParticle]->getParticleVel();

                    avr_tot_pe[k] /= ((double) Nskip);
                    avr_tot_pe2[k] /= ((double) Nskip);
                    avr_tot_en[k] /= ((double) Nskip);
                    avr_tot_en2[k] /= ((double) Nskip);
                    avr_ub[k] /= ((double) Nskip);
                    
                    avr_cv[k] = (joul_to_cal/Unit_of_energy)*Rgas*( avr_tot_pe2[k] - pow(avr_tot_pe[k], 2.0) ) / pow( (*it)->getTemperature(), 2.0 );
                    
                    avr_rg[k]        /= ((double) Nskip);
                    avr_rsa[k]       /= ((double) Nskip);
                    avr_ahel[k]      /= ((double) Nskip);
                    avr_asph[k]      /= ((double) Nskip);
                    avr_chirality[k] /= ((double) Nskip);

                    avr_elec_pe[k]    /= ((double) Nskip);
                    avr_vdw_pe[k]     /= ((double) Nskip);
                    avr_bond_pe[k]    /= ((double) Nskip);
                    avr_angle_pe[k]   /= ((double) Nskip);
                    avr_torsion_pe[k] /= ((double) Nskip);
                    
                    printf("%5d,%5d,%14.6f,", k+1, iParticle+1, temp);
                    fprintf(file1,"%5d  %5d", k+1, iParticle+1);
                    
                    swarm._Particle[iParticle]->calcParticleKineticEnergy();
                    ekin = swarm._Particle[iParticle]->getParticleKineticEnergy();
                    pe = swarm._Particle[iParticle]->getParticleScore();
                    
    
                    //fprintf(file2,"%12.6f%12.6f%12.6f%12.6f%12.6f", (*it)->getTemperature()/Rgas, avr_cv[k],
                    //                                                 (joul_to_cal/Unit_of_energy)*avr_tot_en[k],
                    //                                                 (joul_to_cal/Unit_of_energy)*avr_tot_pe[k],
                    //                                                (joul_to_cal/Unit_of_energy)*avr_ub[k] );

                    fprintf(file2,"%12.6f%12.6f%12.6f%12.6f%12.6f", (*it)->getTemperature()/Rgas, pow( (joul_to_cal/Unit_of_energy)*pe, 2.0 ),
                            (joul_to_cal/Unit_of_energy) * (pe + ekin),
                            (joul_to_cal/Unit_of_energy) * pe,
                            (joul_to_cal/Unit_of_energy) * swarm._Particle[iParticle]->getParticleBiasEnergy() );
   
                }
                printf("\n");
                fprintf(file1,"\n");
                fprintf(file2,"\n");
                
// Print out coordinates of trajectory
                Iframes+=1;
                fprintf(file3, "MODEL%9d\n",Iframes);
                x = swarm._Particle[iParticle]->getParticlePosition();
                int atindex = 1;
                for (int i = 0; i < swarm.getSwarmParticleDimension(); i += 3, ++atindex) {
                    fprintf(file3,"%6s%5d %4s %3s %s%4d    %8.3f%8.3f%8.3f\n", "ATOM  ", atindex, "CA  ", "ARG", "X", atindex, x[i], x[i+1], x[i+2]);
                }
                fprintf(file3, "TER\n");
                fprintf(file3, "ENDMDL\n");

                printf("%37s", "Bond energy (kcal/mol)          =,   ");
                for (k=0; k < Nthermos; k++) printf("%12.5f,", avr_bond_pe[k]*(joul_to_cal/Unit_of_energy));
                printf("\n");

                printf("%37s", "Angle energy (kcal/mol)         =,   ");
                for (k=0; k < Nthermos; k++) printf("%12.5f,", avr_angle_pe[k]*(joul_to_cal/Unit_of_energy));
                printf("\n");

                printf("%37s", "Torsion energy (kcal/mol)       =,   ");
                for (k=0; k < Nthermos; k++) printf("%12.5f,", avr_torsion_pe[k]*(joul_to_cal/Unit_of_energy));
                printf("\n");

                printf("%37s", "Electrostatic energy (kcal/mol) =,   ");
                for (k=0; k < Nthermos; k++) printf("%12.5f,", avr_elec_pe[k]*(joul_to_cal/Unit_of_energy));
                printf("\n");

                printf("%37s", "van der Waals energy (kcal/mol) =,   ");
                for (k=0; k < Nthermos; k++) printf("%12.5f,", avr_vdw_pe[k]*(joul_to_cal/Unit_of_energy));
                printf("\n");

                printf("%37s", "Total energy (kcal/mol)         =,   ");
                for (k=0; k < Nthermos; k++) printf("%12.5f,", avr_tot_pe[k]*(joul_to_cal/Unit_of_energy));
                printf("\n");
                
                printf("%37s", "Heat capacity (kcal/mol/K)      =,   ");
                for (k=0; k < Nthermos; k++) printf("%12.5f,", avr_cv[k]);
                printf("\n");
                
                printf("%37s", "Radius of Gyration (Angstrom)   =,   ");
                for (k=0; k < Nthermos; k++) printf("%12.5f,", avr_rg[k]);
                printf("\n");

                printf("%37s", "Scaled chirality index          =,   ");
                for (k=0; k < Nthermos; k++) printf("%12.5f,", avr_chirality[k]);
                printf("\n");

                printf("%37s", "Relative shape anisotropy       =,   ");
                for (k=0; k < Nthermos; k++) printf("%12.5f,", avr_rsa[k]);
                printf("\n");
                
                printf("%37s", "Asphericity                     =,   ");
                for (k=0; k < Nthermos; k++) printf("%12.5f,", avr_asph[k]);
                printf("\n");
                
                printf("%37s", "Ahelicity                       =,   ");
                for (k=0; k < Nthermos; k++) printf("%12.5f,", avr_ahel[k]);
                printf("\n");

                
                printf("%37s", "Dihedral Angles (Deg.)          =,   ");
                for (k=0; k < Ndihes; k++) printf("%12.5f,", avr_DiheAngles[k]/((double) (Nskip*Nthermos))/toRad );
                printf("\n");

                printf("-----------------------------------------------------------------------------------------------------------------------------\n");

                // Initialize the accumulators to zero
                for (k = 0; k < Nthermos; k++) {
                    avr_rg[k] = 0.0;
                    avr_chirality[k] = 0.0;
                    avr_rsa[k] = 0.0;
                    avr_asph[k] = 0.0;
                    avr_ahel[k] = 0.0;
                    avr_elec_pe[k] = 0.0;
                    avr_vdw_pe[k] = 0.0;
                    avr_bond_pe[k] = 0.0;
                    avr_angle_pe[k] = 0.0;
                    avr_torsion_pe[k] = 0.0;
                    avr_ke[k] = 0.0;
                    avr_tot_pe[k] = 0.0;
                    avr_tot_en[k] = 0.0;
                    avr_tot_pe2[k] = 0.0;
                    avr_tot_en2[k] = 0.0;
                    avr_ub[k] = 0.0;
                }
                for (k=0; k < Ndihes; k++) avr_DiheAngles[k] = 0.0;
                
            }
            if ( iter%Nswaps == 0 ) SwarmSwap(swarm);
        }
    }
    fclose(file1);
    fclose(file2);
    fclose(file3);
    swarm.~CSwarm();
    
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    cout << "CPU time usage:" << endl;
    gettimeofday(&tvEnd, NULL);
    _timeval_print(&tvEnd);
    _timeval_subtract(&tvDiff, &tvEnd, &tvBegin);
    printf("Total CPU time (in seconds):   %ld.%06d\n", tvDiff.tv_sec, tvDiff.tv_usec);
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    outputLogo();
    exit(0);
    return 0;
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void SwarmSwap(CSwarm& cswarm) {
    int k1,k2,ithermo,ithermo_0;
    double r = drand(0.0,1.0);
    double e1, e2, arg, beta1, beta2, kt1, kt2;
    
    if (r > 0.5) ithermo_0 = 0;
    else ithermo_0  = 1;

    for( ithermo = ithermo_0; ithermo < Nthermos-1; ithermo += 2 ) {
        k1 = cswarm._Thermo[ithermo]->getThermostatParticle();
        k2 = cswarm._Thermo[ithermo+1]->getThermostatParticle();
        e1 = cswarm._Particle[k1]->getParticleKineticEnergy() + cswarm._Particle[k1]->getParticleScore();
        e2 = cswarm._Particle[k2]->getParticleKineticEnergy() + cswarm._Particle[k2]->getParticleScore();
        kt1 = cswarm._Thermo[ithermo]->getTemperature();
        kt2 = cswarm._Thermo[ithermo+1]->getTemperature();
        beta1 = 1.0/kt1;
        beta2 = 1.0/kt2;
        arg = (beta1 - beta2)*(e2 - e1);
        if (arg <= 0.0) {
            cswarm._Thermo[ithermo]->setThermostatParticle(k2);
            cswarm._Thermo[ithermo+1]->setThermostatParticle(k1);
            cswarm._Particle[k1]->setupWeights(kt2);
            cswarm._Particle[k1]->scaleParticleVel( sqrt(kt2/kt1) );
            cswarm._Particle[k2]->setupWeights(kt1);
            cswarm._Particle[k2]->scaleParticleVel( sqrt(kt1/kt2) );
        }
        else if (arg <= 100.0) {
            r = drand(0.0,1.0);
            if ( r < exp(-arg) ) {
                cswarm._Thermo[ithermo]->setThermostatParticle(k2);
                cswarm._Thermo[ithermo+1]->setThermostatParticle(k1);
                cswarm._Particle[k1]->setupWeights(kt2);
                cswarm._Particle[k1]->scaleParticleVel( sqrt(kt2/kt1) );
                cswarm._Particle[k2]->setupWeights(kt1);
                cswarm._Particle[k2]->scaleParticleVel( sqrt(kt1/kt2) );
           }
        }
    }
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void inputLogo(){
    cout << "                                     -                                 " << endl;
    cout << "                                  ------                               " << endl;
    cout << "                               ------------                            " << endl;
    cout << " ------------      Replica Exchange Molecular Dynamics     ------------" << endl;
    cout << " ------------    Using Nose-Hoover thermostating approach  ------------" << endl;
    cout << " ------------    Dynamics are biased using Swarm Particle  ------------" << endl;
    cout << " ------------                   Technique                  ------------" << endl;
    cout << " ------------    Author: Hiqmet Kamberaj                   ------------" << endl;
    cout << " ------------    Address: International Balkan University  ------------" << endl;
    cout << " ------------    Email: h.kamberaj@gmail.com               ------------" << endl;
    cout << "                               ------------                            " << endl;
    cout << "                                  ------                               " << endl;
    cout << "                                     -                                 " << endl;
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void outputLogo(){
    cout << "                                   -                                   " << endl;
    cout << "                                ------                                 " << endl;
    cout << "                             ------------                              " << endl;
    cout << " ------------     Replica Exchange Molecular Dynamics      ------------" << endl;
    cout << " ------------           using Swarm Particle               ------------" << endl;
    cout << " ------------                Technique                     ------------" << endl;
    cout << " ------------           Finished Successfully!!!           ------------" << endl;
    cout << " ------------   Comments should be addressed to the author ------------" << endl;
    cout << " ------------   Author: Hiqmet Kamberaj                    ------------" << endl;
    cout << " ------------   Address: International Balkan University   ------------" << endl;
    cout << " ------------   Email: h.kamberaj@gmail.com                ------------" << endl;
    cout << "                             ------------                              " << endl;
    cout << "                                ------                                 " << endl;
    cout << "                                   -                                   " << endl;
}
