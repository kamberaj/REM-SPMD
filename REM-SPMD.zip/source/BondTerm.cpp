  //
//  BondTerm.cpp
//  
//
//  Created by Hiqmet Kamberaj on 29/01/2016.
//
//

#include "BondTerm.hpp"

#include <iostream>
#include <cmath>
#include <vector>

#include "defs.hpp"

using namespace std;


namespace spo {
    BondTerm::BondTerm() {
    }
    BondTerm::BondTerm(int ndim, molStruct molecule, ffDefs _ffp) {
        double b0;
        double x1[3], x2[3];
        int I;
        this->Ndim = ndim;
        int natoms=ndim/3;
        for (I = 0; I < ndim; I++) {
            this->force.push_back(0.0);
        }
        for (I = 0; I < natoms-1; I++) {
            x1[0] = molecule.pAtom[I].X;
            x1[1] = molecule.pAtom[I].Y;
            x1[2] = molecule.pAtom[I].Z;
            
            x2[0] = molecule.pAtom[I+1].X;
            x2[1] = molecule.pAtom[I+1].Y;
            x2[2] = molecule.pAtom[I+1].Z;

            b0 = 3.8;
            double kforce = 70.0 * bondunit * Unit_of_energy;
            cout << I << "   "  << I+1 << "  " << kforce << endl;
            this->_BondType.push_back( new BondType(3, I, I+1, b0, kforce) );
        }
    }
    BondTerm::BondTerm( const BondTerm& orig ){
    }
    BondTerm::~BondTerm(){
    }
    double BondTerm::getBondLength(double x1[], double x2[], int dim){
        double di[dim];
        double ri2;
        ri2 = 0.0;
        for (int i=0; i < dim; i++) {
            di[i] = x1[i] - x2[i];
            ri2 += (di[i] * di[i]);
        }
        return sqrt( ri2 );
    }
    void BondTerm::calcEnergy(vector<double> X){
        int IA, IB;
        double xa[3], xb[3];
        vector<double> fa, fb;
        for (int i=0; i < 3; i++) {
            fa.push_back(0.0);
            fb.push_back(0.0);
        }
// Initialize forces and energy to zero
        this->BondPot = 0.0;
        for (int i = 0; i < this->Ndim; i++) this->force[i] = 0.0;
        
        for (std::vector<BondType*>::const_iterator it = _BondType.begin(); it != _BondType.end(); ++it) {
            IA = (*it)->getBondAtomIndexA();
            IB = (*it)->getBondAtomIndexB();
            for (int i=0; i < 3; i++){
                xa[i] = X[IA*3+i];
                xb[i] = X[IB*3+i];
            }
            (*it)->calcBondStretchingGradient(xa, xb, 3);
            fa = (*it)->getBondStretchingGradientAtomTypeA();
            fb = (*it)->getBondStretchingGradientAtomTypeB();
            for (int i=0; i < 3; i++){
                this->force[IA*3+i] += fa[i];
                this->force[IB*3+i] += fb[i];
            }
            this->BondPot += (*it)->getEnergy();
        }
    }
    vector<double> BondTerm::getForces(){
        return this->force;
    }
    double BondTerm::getEnergy(){
        return this->BondPot;
    }
 
}


