//
//  VdwTerm.cpp
//  
//
//  Created by Hiqmet Kamberaj on 01/07/2015.
//
//

#include "VdwTerm.hpp"

#include <iostream>
#include <cmath>
#include <vector>

#include "Maths.hpp"
#include "defs.hpp"

using namespace std;
using namespace maths;

namespace spo {
    VdwTerm::VdwTerm() {
    }
    VdwTerm::VdwTerm(int ndim, molStruct molecule, ffDefs _ff) {
        double Rmin_ij;
        double dx[3];
        double Alpha;
        double Eps;
        this->Ndim = ndim;
        int natoms = ndim/3;
        cout << natoms << endl;
        for (int i=0; i < ndim; i++) {
            this->force.push_back(0.0);
        }
        for (int I = 0; I < natoms-3; I++) {
            for (int J = I+3; J < natoms; J++) {
                dx[0] = molecule.pAtom[I].X - molecule.pAtom[J].X;
                dx[1] = molecule.pAtom[I].Y - molecule.pAtom[J].Y;
                dx[2] = molecule.pAtom[I].Z - molecule.pAtom[J].Z;
                Rmin_ij = sqrt( _dot_product(dx, dx) );
                if (Rmin_ij <= 6.5) {
                    Eps   = 6.0 * exp( -Rmin_ij / 2.8 ) * Unit_of_energy * cal_to_joul;
                    Alpha = 0.7;
                    this->_vdwType.push_back( new VdwType(3, I, J, Rmin_ij, Eps, Alpha, 3) );
                }
                else {
                    Eps     = 0.20708 * Unit_of_energy * cal_to_joul;
                    Rmin_ij = 9.75;
                    Alpha   = 0.70711;
                    this->_vdwType.push_back( new VdwType(3, I, J, Rmin_ij, Eps, Alpha, 3) );
                }
            }
        }
    }
    VdwTerm::VdwTerm( const VdwTerm& orig ){
    }
    VdwTerm::~VdwTerm(){
    }
    void VdwTerm::calcEnergy(vector<double> X){
        int IA, IB;
        double eps, alpha;
        double rmin;
        double xa[3], xb[3];
        vector<double> fa, fb;
        int type;
        for (int i=0; i < 3; i++) {
            fa.push_back(0.0);
            fb.push_back(0.0);
        }
// Initialize pot and forces
        this->vdwPot = 0.0;
        for (int i = 0; i < this->Ndim; i++) this->force[i] = 0.0;
        
        for (std::vector<VdwType*>::const_iterator it = _vdwType.begin(); it != _vdwType.end(); ++it) {
            IA = (*it)->getVdwAtomIndexA();
            IB = (*it)->getVdwAtomIndexB();
            rmin  = (*it)->getVdwRmin();
            eps   = (*it)->getVdwPotDepth();
            alpha = (*it)->getVdwAlpha();
            type  = (*it)->getVdwType();
            for (int i = 0; i < 3; i++){
                xa[i] = X[IA*3+i];
                xb[i] = X[IB*3+i];
            }
            (*it)->calcVdwGradient(xa, xb, 3, eps, rmin, alpha, type);
            fa = (*it)->getVdwGradientAtomTypeA();
            fb = (*it)->getVdwGradientAtomTypeB();
            for (int i = 0; i < 3; i++){
                this->force[IA*3+i] += fa[i];
                this->force[IB*3+i] += fb[i];
            }
            this->vdwPot += (*it)->getEnergy();
        }
    }
    vector<double> VdwTerm::getForces(){
        return this->force;
    }
    double VdwTerm::getEnergy(){
        return this->vdwPot;
    }
}


