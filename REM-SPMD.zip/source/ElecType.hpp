//
//  ElecType.h
//  
//
//  Created by Hiqmet Kamberaj on 30/06/2015.
//
//

#ifndef ____ElecType__
#define ____ElecType__

#include <vector>

using namespace std;

namespace spo {
    class ElecType {
    public:
        ElecType();
        ElecType(int ndim, int I, int J, double qi, double qj, double eps);
        ElecType(const ElecType& orig);
        virtual ~ElecType();
        
        double getCharge();
        void setCharge(double e);

        double getDielectricConstant();
        void setDielectricConstant(double e);
        
        void setElecAtomIndexA(int r);
        int  getElecAtomIndexA();
        void setElecAtomIndexB(int r);
        int  getElecAtomIndexB();

        double getEnergy();
        void calcElecGradient(double x1[], double x2[], int dim, double qij, double eps);
        vector<double> getElecGradientAtomTypeA();
        vector<double> getElecGradientAtomTypeB();
        
        void setElecAtomTypeA(char atype[]);
        void setElecAtomTypeB(char atype[]);
        void getElecAtomTypeA(char atype[]);
        void getElecAtomTypeB(char atype[]);
        
    private:
        double Epsilon;
        double Charge_ij;
        double e;
        vector<double> forceA;
        vector<double> forceB;
        char atomTypeA[4];
        char atomTypeB[4];
        int AtomIndexA, AtomIndexB;
    };
    
}

#endif /* defined(____ElecType__) */
