//
//  ElecTerm.h
//  
//
//  Created by Hiqmet Kamberaj on 29/01/2016.
//
//

#ifndef ____ElecTerm__
#define ____ElecTerm__

#include <vector>

#include "ElecType.hpp"
#include "defs.hpp"


using namespace std;

namespace spo {
    class ElecTerm {
    public:
        ElecTerm();
        ElecTerm(int ndim, molStruct molecule, ffDefs _ff);
        ElecTerm(const ElecTerm& orig);
        virtual ~ElecTerm();
        
        vector <ElecType*> _ElecType;
        
        void calcEnergy(vector<double> X);
        vector<double> getForces();
        double getEnergy();
        
    private:
        int Ndim;
        double ElecPot;
        vector<double> force;
    };
}
#endif /* defined(____ElecTerm__) */
