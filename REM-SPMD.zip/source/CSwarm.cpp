/* 
 * File:   CSwarm.cpp
 * Author: Hiqmet Kamberaj
 * 
 * Created on November 26, 2010, 12:26 PM
 */

#include "CSwarm.hpp"
#include "Maths.hpp"
#include "CParticle.hpp"
#include "Nosethermo.hpp"

#include "FFParams.hpp"

#include <vector>

#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <cmath>

using namespace std;
using namespace nose;
using namespace maths;

using namespace ffp;

namespace spo {
    CSwarm::CSwarm() {
        this->Score_Gbest = 1.0e+20;
    }
    CSwarm::CSwarm(const CSwarm& orig) {
    }

    CSwarm::CSwarm(int np, int nd, double xmin, double xmax, double dt, int m, double tau, double kt0, double kt, short int qbias){
        this->Xmin = xmin;
        this->Xmax = xmax;
        this->Dt = dt;
        this->KT = kt;
        this->KT0= kt0;
        this->Nparticles = np;
        this->Ndim = nd;
        this->Nthermos = np;
        this->Score_Gbest = 1.0e+20;
        setupSwarmParticles(qbias);
        setupSwarmThermostats(np, m, tau);
        cout << "Read FF parameters" << endl;
        FILE *file3 = fopen("../source/prm/cgff.prm", "r");
        cout << "Open file -->" << endl;
        _ffp = FFParams(file3);
        fclose(file3);
        cout << ".... Done ......." << endl;
    }
    CSwarm::~CSwarm() {
       this->Xmin = 0.0;
       this->Xmax = 0.0;
       this->Score_Gbest = 1.0e+20;
       for (std::vector<CParticle*>::const_iterator it = _Particle.begin(); it != _Particle.end(); ++it) {
           (*it)->~CParticle();
       }
    }

    
    ////////////////////////////////////////////////////////////////////////////
    
    void CSwarm::setupSwarmThermostats(int nthermos, int m, double tau) {
        double kt;
        double r = pow(this->KT / this->KT0, 1.0/(double) (nthermos-1));
        for (int i = 0; i < nthermos; ++i) {
            kt = this->KT0 * pow(r, (double) i);
            cout << kt << endl;
            _Thermo.push_back(new Thermostat(this->Ndim, kt, tau, m, i));
        }
    }
    
    ///////////////////////////////////////////////////////////////////////////////
    int CSwarm::getSwarmParticleDimension() {
        return this->Ndim;
    }

 ////////////////////////////////////////////////////////////////////////////

    void CSwarm::setupSwarmParticles(short int qbias) {
        double kt;

        double r = pow(this->KT / this->KT0, 1.0/(double) (this->Nparticles-1));
        for (int i=0; i < this->Nparticles; ++i) {
            kt = this->KT0 * pow(r, (double) i);
            _Particle.push_back(new CParticle(this->Ndim,kt,qbias));
        }
    }

    void CSwarm::initSwarmParticles(double mass, bool fileStart) {
        double kt;
        double r = pow(this->KT / this->KT0, 1.0/(double) (this->Nparticles-1));
        int i = 0;
        for (std::vector<CParticle*>::const_iterator it = _Particle.begin(); it != _Particle.end(); ++it, ++i) {
            kt = this->KT0 * pow(r, (double) i);
            (*it)->initParticleMass(mass);
            (*it)->initParticlePosition(this->Xmin, this->Xmax, _ffp.ff, fileStart);
            (*it)->initParticleVel(kt);
            (*it)->initParticleForce();
        }
    }
    
    void CSwarm::RandomInitSwarmParticles() {
        for (std::vector<CParticle*>::const_iterator it = _Particle.begin(); it != _Particle.end(); ++it) {
            (*it)->RandomInitParticlePosition(this->Xmin, this->Xmax);
        }
    }

    ////////////////////////////////////////////////////////////////////////////

    void CSwarm::setupSwarmGlobalBestPosition() {
        for (int i = 0; i < this->Ndim; ++i)
            X_Gbest.push_back(0.0);
        
    }
    void CSwarm::updateSwarmGlobalBestPosition() {
       for (std::vector<CParticle*>::const_iterator it = _Particle.begin(); it != _Particle.end(); ++it) {
            if ( (*it)->getParticleScore() < this->Score_Gbest ) {
                this->Score_Gbest = (*it)->getParticleScore();
                this->X_Gbest = (*it)->getParticlePosition();
            }
       }
    }
    vector<double> CSwarm::getSwarmGlobalBestPosition() {
        return X_Gbest;
    }
    void CSwarm::deleteSwarmGlobalBestPosition() {
        this->X_Gbest.erase(this->X_Gbest.begin(), this->X_Gbest.end());
    }
    ////////////////////////////////////////////////////////////////////////////

    double CSwarm::getSwarmGlobalBestScore() { return this->Score_Gbest; }

    
    ////////////////////////////////////////////////////////////////////////
    void CSwarm::moveNoseThermostatNextStep() {
        int iParticle;
        vector <double> v;
        for (std::vector<Thermostat*>::const_iterator it = this->_Thermo.begin(); it != this->_Thermo.end(); ++it) {
            iParticle = (*it)->getThermostatParticle();
            v = _Particle[iParticle]->getParticleVel();
            (*it)->UpdateThermostatVariables(v, _Particle[iParticle]->getParticleMass(), this->Dt);
            _Particle[iParticle]->setParticleVel(v);
        }
    }
    ////////////////////////////////////////////////////////////////////////
    void CSwarm::moveVelocityNextStep() {
        // --- Update local and global best positions of swarm
        for (std::vector<CParticle*>::const_iterator it = this->_Particle.begin(); it != this->_Particle.end(); ++it) {
                (*it)->updateLocalBestParticlePosition();
        }
        this->updateSwarmGlobalBestPosition();

        // --- move X and V from t -> t+1
        for (std::vector<CParticle*>::const_iterator it = this->_Particle.begin(); it != this->_Particle.end(); ++it) {
            (*it)->updateParticleVel(this->getSwarmGlobalBestPosition(), this->Dt);
         }
    }

    void CSwarm::movePositionNextStep() {
        // --- move X and V from t -> t+1
        for (std::vector<CParticle*>::const_iterator it = this->_Particle.begin(); it != this->_Particle.end(); ++it) {
            (*it)->updateParticlePosition(this->getSwarmGlobalBestPosition(), this->Dt);
        }
    }
    
    ////////////////////////////////////////////////////////////////////////////
    void CSwarm::calcSwarmDiversity() {
        double xL;
        this->Diversity = 0.0;
        for (std::vector<CParticle*>::const_iterator it = this->_Particle.begin(); it != this->_Particle.end(); ++it) {
            double dot = 0.0;
            for (int i = 0; i < this->Ndim; ++i){
                xL = (*it)->getLocalBestParticlePositionIndex(i);
                dot += (this->X_Gbest[i] - xL)*(this->X_Gbest[i] - xL);
            }
            this->Diversity += sqrt( dot );
        }
        this->Diversity /= (double)this->Nparticles;
    }
    double CSwarm::getSwarmDiversity() {
        return this->Diversity;
    }

} // end of namespace Spo

