/*
 * File:   defs.hpp
 * Author: Hiqmet Kamberaj
 *
 * Created on November 25, 2010, 1:49 PM
 */

#ifndef DEFS_HPP
#define	DEFS_HPP

const double torsunit  = 1.0;
const double bondunit  = 1.0;
const double angleunit = 0.5;

const double cal_to_joul    = 4.18579996;          // Cal to Joul
const double joul_to_cal    = 0.2389029599016;     // Joul to Cal
const double Amu_to_kgmol   = 0.001;               // kg / mol
const double Unit_of_energy = 0.1;                 // 10^3 * kg * m^2 / s^2 / mol -> kg * Angstrom^2 / (ps)^2 / mol

const double mass    = 12.0*Amu_to_kgmol;          // mass in kg/mol

const double Rgas = 0.00083144722;                 // in kg * Angstrom^2 / (ps)^2 / mol
const double tau  = 0.1;
const int M       = 3;

const double toRad = 0.01745329251994;
const double cutoff  = 15.0;
const double cutoff2 = cutoff*cutoff;

const double scale_charge = 18.226922;


typedef struct {
    double X, Y, Z;
    char atname[6];
    char resname[4];
    char chainname[2];
} AtomProperty;

typedef struct {
    int natoms;
    int ndim;
    AtomProperty *pAtom;
} molStruct;

typedef struct {
    double kforce;
    double eqLength;
} BondParam;

typedef struct {
    double kforce1, kforce2;
    double eqAngle1, eqAngle2;
    char resname1[4], resname2[4], resname3[4];
} AngleParam;

typedef struct {
    double kforce;
} TorsionParam;

typedef struct {
    int nbonds;
    BondParam *ffBond;
    int nangles;
    AngleParam *ffAngle;
    int ntorsions;
    TorsionParam *ffTorsion;
} ffDefs;


#endif	/* DEFS_HPP */
