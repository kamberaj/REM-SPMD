//
//  ElecType.cpp
//  
//
//  Created by Hiqmet Kamberaj on 30/06/2015.
//
//

#include "ElecType.hpp"

#include <iostream>
#include <cmath>
#include <cstring>
#include <vector>

#include "Maths.hpp"

using namespace std;
using namespace maths;

namespace spo {
    ElecType::ElecType() {
    }
    ElecType::ElecType(int ndim, int I, int J, double qi, double qj, double eps) {
        for (int i=0; i < ndim; i++) {
            this->forceA.push_back(0.0);
            this->forceB.push_back(0.0);
        }
        double qij = qi * qj;
        setCharge(qij);
        setDielectricConstant(eps);
        setElecAtomIndexA(I);
        setElecAtomIndexB(J);
    }
    ElecType::ElecType(const ElecType& orig){
    }
    ElecType::~ElecType(){
    }
    double ElecType::getCharge(){
        return this->Charge_ij;
    }
    void ElecType::setCharge(double qij){
        this->Charge_ij = qij;
    }
    double ElecType::getDielectricConstant(){
        return this->Epsilon;
    }
    void ElecType::setDielectricConstant(double e){
        this->Epsilon = e;
    }
    double ElecType::getEnergy(){
        return this->e;
    }
    void ElecType::calcElecGradient(double x1[], double x2[], int dim, double qij, double e){
        double dx[dim];
        double r, r2, r2r;
        r2 = 0.0;
        for (int i=0; i < dim; i++) {
            dx[i] = x1[i] - x2[i];
            r2   += dx[i] * dx[i];
        }
        if (r2 <= cutoff2) {
            r2r = 1.0 /r2;
            this->e = qij*r2r / e;
            double dudr = 2.0 * qij * r2r * r2r / e;
            for (int i=0; i < dim; i++){
                this->forceA[i] =  dudr * dx[i];
                this->forceB[i] = -dudr * dx[i];
            }
        }
    }
    vector<double> ElecType::getElecGradientAtomTypeA(){
        return this->forceA;
    }
    vector<double> ElecType::getElecGradientAtomTypeB(){
        return this->forceB;
    }
    
    void ElecType::setElecAtomTypeA(char atype[]){
        strcpy(this->atomTypeA, atype);
    }
    void ElecType::getElecAtomTypeA(char atype[]){
        strcpy(atype, this->atomTypeA);
    }
    void ElecType::setElecAtomTypeB(char atype[]){
        strcpy(this->atomTypeB, atype);
    }
    void ElecType::getElecAtomTypeB(char atype[]){
        strcpy(atype, this->atomTypeB);
    }


    void ElecType::setElecAtomIndexA(int i){
        AtomIndexA = i;
    }
    int ElecType::getElecAtomIndexA(){
        return this->AtomIndexA;
    }
    
    void ElecType::setElecAtomIndexB(int i){
        AtomIndexB = i;
    }
    int ElecType::getElecAtomIndexB(){
        return this->AtomIndexB;
    }


}

