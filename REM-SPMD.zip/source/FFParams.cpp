//
//  FFParams.cpp
//  
//
//  Created by Hiqmet Kamberaj on 29/01/2016.
//
//

#include "FFParams.hpp"

#include <iostream>
#include <cmath>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#include "Maths.hpp"

using namespace std;
using namespace maths;

namespace ffp {
    FFParams::FFParams() {
    }
    FFParams::FFParams(FILE *fp) {
        readFFparam(fp);
    }
    FFParams::FFParams( const FFParams& orig ){
    }
    FFParams::~FFParams(){
    }
    
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    ffDefs FFParams::getFFParams(){
        return this->ff;
    }
    void FFParams::readFFparam(FILE *fp) {
        char header[80];
        double kbond, bondlength;
        double ktorsion;
        double kangle1, kangle2;
        double angle1, angle2;
        char t_resname1[4];
        char t_resname2[4];
        char t_resname3[4];
        int nbonds;
        int ntorsions;
        int nangles;
        
        fscanf(fp,"%s\n",header);
        if ( strcmp(header, "BOND") == 0 ) {
            fscanf(fp, "%d\n", &nbonds);
            cout << nbonds << endl;
            this->ff.nbonds = nbonds;
            cout << this->ff.nbonds << endl;
            this->ff.ffBond = new BondParam[nbonds];
            for (int i=0; i < nbonds; i++) {
                fscanf(fp, "%lf  %lf\n", &kbond, &bondlength);
                cout << kbond << "   " << bondlength << endl;
                this->ff.ffBond[i].kforce = kbond * cal_to_joul;
                this->ff.ffBond[i].eqLength = bondlength;
            }
        }
        
        fscanf(fp,"%s\n",header);
        if ( strcmp(header, "TORSION") == 0 ) {
            fscanf(fp, "%d\n", &ntorsions);
            cout << ntorsions << endl;
            this->ff.ntorsions = ntorsions;
            this->ff.ffTorsion = new TorsionParam[ntorsions];
            for (int i=0; i < ntorsions; i++) {
                fscanf(fp, "%lf\n", &ktorsion);
                cout << ktorsion << endl;
                this->ff.ffTorsion[i].kforce = ktorsion * cal_to_joul;
            }
        }
        fscanf(fp,"%s\n",header);
        if ( strcmp(header, "ANGLE") == 0 ) {
            fscanf(fp, "%d\n", &nangles);
            cout << nangles << endl;
            this->ff.nangles = nangles;
            this->ff.ffAngle = new AngleParam[nangles];
            for (int i=0; i < nangles; i++) {
                fscanf(fp, "%s  %s  %s  %lf  %lf  %lf  %lf\n", t_resname1, t_resname2, t_resname3, &kangle1, &angle1, &kangle2, &angle2);
                this->ff.ffAngle[i].kforce1  = kangle1 * cal_to_joul;
                this->ff.ffAngle[i].kforce2  = kangle2 * cal_to_joul;
                this->ff.ffAngle[i].eqAngle1 = angle1;
                this->ff.ffAngle[i].eqAngle2 = angle2;
                strcpy( this->ff.ffAngle[i].resname1, t_resname1 );
                strcpy( this->ff.ffAngle[i].resname2, t_resname2 );
                strcpy( this->ff.ffAngle[i].resname3, t_resname3 );
                _toUpper(this->ff.ffAngle[i].resname1, this->ff.ffAngle[i].resname1, 4);
                _toUpper(this->ff.ffAngle[i].resname2, this->ff.ffAngle[i].resname2, 4);
                _toUpper(this->ff.ffAngle[i].resname3, this->ff.ffAngle[i].resname3, 4);
                
            }
        }
        cout << "....... Done with reading the  FF parameters" << endl;
    }
 
}


