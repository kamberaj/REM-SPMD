//
//  AngleTerm.cpp
//  
//
//  Created by Hiqmet Kamberaj on 29/01/2016.
//
//

#include "AngleTerm.hpp"

#include <iostream>
#include <cmath>
#include <vector>
#include <cstring>

#include "defs.hpp"
#include "Maths.hpp"

using namespace std;
using namespace maths;


namespace spo {
    AngleTerm::AngleTerm() {
    }
    AngleTerm::AngleTerm(int ndim, molStruct molecule, ffDefs ff) {
        double theta0[2];
        double kforce[3];
        double x1[3],x2[3],x3[3];
        double delta;
        bool found = false;
        int I, J, K;
        this->Ndim = ndim;
        int natoms = ndim/3;
        for (I=0; I < ndim; I++) {
            this->force.push_back(0.0);
        }
        for (I = 0; I < natoms-2; I++) {
            J=I+1;
            K=I+2;
            found = false;
            for (int m=0; m < ff.nangles; m++) {
                if (strcmp(ff.ffAngle[m].resname1, molecule.pAtom[I].resname) == 0 &&
                    strcmp(ff.ffAngle[m].resname2, molecule.pAtom[J].resname) == 0 &&
                    strcmp(ff.ffAngle[m].resname3, molecule.pAtom[K].resname) == 0) {

                    theta0[0] = ff.ffAngle[m].eqAngle1 * toRad;
                    theta0[1] = ff.ffAngle[m].eqAngle2 * toRad;
                    
                    delta     = theta0[1] - theta0[0];
                    kforce[0] =   0.5 *      Unit_of_energy * angleunit *  ff.ffAngle[m].kforce1;
                    kforce[1] = -(1.0/3.0) * Unit_of_energy * angleunit * (ff.ffAngle[m].kforce2 + 2.0 * ff.ffAngle[m].kforce1)/delta;
                    kforce[2] =   0.25 *     Unit_of_energy * angleunit * (ff.ffAngle[m].kforce2 +       ff.ffAngle[m].kforce1)/(delta*delta);
                    found = true;
                    break;
                }
            }
            if (found == false) {
                cout << "Warning: No parameters found for the angle:  " << molecule.pAtom[I].resname << "  " << molecule.pAtom[J].resname << "  " << molecule.pAtom[K].resname << endl;
                for (int m=0; m < ff.nangles; m++) {
                    if (strcmp(ff.ffAngle[m].resname2, molecule.pAtom[J].resname) == 0) {
                        
                        theta0[0] = ff.ffAngle[m].eqAngle1 * toRad;
                        theta0[1] = ff.ffAngle[m].eqAngle2 * toRad;
                        
                        delta     = theta0[1] - theta0[0];
                        kforce[0] =   0.5 *      Unit_of_energy * angleunit *  ff.ffAngle[m].kforce1;
                        kforce[1] = -(1.0/3.0) * Unit_of_energy * angleunit * (ff.ffAngle[m].kforce2 + 2.0 * ff.ffAngle[m].kforce1)/delta;
                        kforce[2] =   0.25 *     Unit_of_energy * angleunit * (ff.ffAngle[m].kforce2 +       ff.ffAngle[m].kforce1)/(delta*delta);
                        found = true;
                        break;
                    }
                }
                if (found == false) {
                    cout << "Stop: No parameters found for the angle:  " << molecule.pAtom[I].resname << "  " << molecule.pAtom[J].resname << "  " << molecule.pAtom[K].resname << endl;
                    exit(1);
                }
            }
            else if (found == true) {
                found = false;
            }
            else {
                cout << "Stop: Unexpected value of FOUND parameter in AngleTerm function" << endl;
                exit(1);
            }
            
            cout << I+1 << "  " << J+1 << "  " << K+1 << "   " << theta0[0] << "  " << kforce[0] << "  " << kforce[1] << "  " << kforce[2] << endl;
            
            /*
            x1[0] = molecule.pAtom[I].X;
            x1[1] = molecule.pAtom[I].Y;
            x1[2] = molecule.pAtom[I].Z;

            x2[0] = molecule.pAtom[J].X;
            x2[1] = molecule.pAtom[J].Y;
            x2[2] = molecule.pAtom[J].Z;

            x3[0] = molecule.pAtom[K].X;
            x3[1] = molecule.pAtom[K].Y;
            x3[2] = molecule.pAtom[K].Z;

            theta0[0] = getAngle(x1, x2, x3, 3);
             */
            
            this->_AngleType.push_back( new AngleType(3, I, J, K, theta0[0], kforce) );
        }
    }
    AngleTerm::AngleTerm( const AngleTerm& orig ){
    }
    AngleTerm::~AngleTerm(){
    }
    double AngleTerm::getAngle(double x1[], double x2[], double x3[], int dim){
        double di[dim], dir[dim];
        double dj[dim], djr[dim];
        double ctheta, ri, ri2, rj, rj2, rir, rjr;
        ri2 = 0.0;
        rj2 = 0.0;
        for (int i=0; i < dim; i++) {
            di[i] = x1[i] - x2[i];
            dj[i] = x3[i] - x2[i];
            ri2 += (di[i] * di[i]);
            rj2 += (dj[i] * dj[i]);
        }
        ri = sqrt( ri2 );
        rj = sqrt( rj2 );
        rir = 1.0/ri;
        rjr = 1.0/rj;
        ctheta = 0.0;
        for (int i=0; i < dim; i++) {
            dir[i] = di[i] * rir;
            djr[i] = dj[i] * rjr;
            ctheta += dir[i] * djr[i];
        }
        if (ctheta > 1.0) ctheta = sign(1.0, ctheta);
        return acos( ctheta );
    }
    void AngleTerm::calcEnergy(vector<double> X){
        int IA, IB, IC;
        double xa[3], xb[3], xc[3];
        vector<double> fa, fb, fc;
        for (int i=0; i < 3; i++) {
            fa.push_back(0.0);
            fb.push_back(0.0);
            fc.push_back(0.0);
        }
// Initialize pot and forces
        this->AnglePot = 0.0;
        for (int i = 0; i < this->Ndim; i++) this->force[i] = 0.0;

        for (std::vector<AngleType*>::const_iterator it = _AngleType.begin(); it != _AngleType.end(); ++it) {
            IA = (*it)->getAngleAtomIndexA();
            IB = (*it)->getAngleAtomIndexB();
            IC = (*it)->getAngleAtomIndexC();
            for (int i = 0; i < 3; i++){
                xa[i] = X[IA*3+i];
                xb[i] = X[IB*3+i];
                xc[i] = X[IC*3+i];
            }
            (*it)->calcAngleGradient(xa, xb, xc, 3);
            fa = (*it)->getAngleGradientAtomTypeA();
            fb = (*it)->getAngleGradientAtomTypeB();
            fc = (*it)->getAngleGradientAtomTypeC();
            for (int i = 0; i < 3; i++){
                this->force[IA*3+i] += fa[i];
                this->force[IB*3+i] += fb[i];
                this->force[IC*3+i] += fc[i];
            }
            this->AnglePot += (*it)->getEnergy();
        }
    }
    vector<double> AngleTerm::getForces(){
        return this->force;
    }
    double AngleTerm::getEnergy(){
        return this->AnglePot;
    }
 
}


