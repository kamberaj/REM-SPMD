/* 
 * File:   Nosethermo.cpp
 * Author: Hiqmet Kamberaj
 * 
 * Created on January, 2015
 */

#include "Nosethermo.hpp"
#include "Random.hpp"
#include "Maths.hpp"

#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <cmath>

using namespace std;
using namespace rangen;
using namespace maths;

namespace nose {

    Nosethermo::Nosethermo() {
    }

    Nosethermo::Nosethermo(double kt, double tau, int m) {
        this->M = m;
        this->Tau = tau;
        this->Nrespa = 20;
        this->setNoseChainTemperature(kt);
        this->initNoseMultipleChains();
    }

    Nosethermo::Nosethermo(const Nosethermo& orig) {
    }

    Nosethermo::~Nosethermo() {
 
    }

    void Nosethermo::refresh() {
    }
    
    ////////////////////////////////////////////////////////////////////////////
    void Nosethermo::setNoseChainTemperature(double kt){
        this->KT = kt;
    }
    int Nosethermo::getNoseChainTemperature(){
        return this->KT;
    }
    
    ////////////////////////////////////////////////////////////////////////////
    void Nosethermo::initNoseMultipleChains(){
        for (int i = 0; i < this->M; ++i) {
            this->Mass.push_back(this->KT * this->Tau * this->Tau);
            this->Pos.push_back(0.0);
            this->G.push_back(0.0);
        }
        for(int i = 0; i < this->M; ++i){
            this->Vel.push_back(sqrt(this->KT/this->Mass[i]) *grand());
        }
    }
    
    ////////////////////////////////////////////////////////////////////////////
    double Nosethermo::getNoseEnergy(){
        double ext=0;
        for (int k=0; k < this->M; k++) {
            ext += 0.5*(this->Vel[k]*this->Vel[k]*this->Mass[k]) + KT*this->Pos[k];
        }
        return (ext);
    }
    ////////////////////////////////////////////////////////////////////////////
    double Nosethermo::_MaclaurinSeries(double x) {
        double x2 = x*x;
        double x4 = x2 * x2;
        double r;
        r = 1.0 + (1.0/6.0)*x2 + (1.0/120.0)*x4 + (1.0/5040.0)*x2*x4 + (1.0/362880.0)*x4*x4;
        return r;
    }
    
    double Nosethermo::update_nhc_respa(double ke2, double Dt){
        double w2 = 0.5*Dt/(double)Nrespa;
        double w4 = 0.5*w2;
        double w8 = 0.5*w4;
        double arg, aa,aa2;
        double scale = 1.0;
        double tke, ms;
        double K = ke2;
        for (int i = 0; i < Nrespa; i++){
            arg = -w4*Vel[0];
            aa = exp(arg);
            aa2 = aa*aa;
            scale *= aa;
            K *= aa2;
            
            G[0] = (K - KT)/Mass[0];
            Vel[M-1] += w4*G[M-1];
            for (int j=0; j < M-1; j++) {
                arg = w8*Vel[M-j-1];
                ms  = _MaclaurinSeries(arg);
                aa  = exp(-arg);
                aa2 = aa*aa;
                Vel[M-j-2] = Vel[M-j-2]*aa2 + w4*aa*ms*G[M-j-2];
            }
            for (int j = 0; j < M; j++) {
                Pos[j] += w2*Vel[j];
            }
            for (int j = 1; j < M; j++) {
                tke =  Vel[j-1]*Vel[j-1]*Mass[j-1];
                G[j] = (tke - KT)/Mass[j];
            }
            
            for (int j=0; j < M-1; j++) {
                arg = w8*Vel[j+1];
                ms  = _MaclaurinSeries(arg);
                aa  = exp(-arg);
                aa2 = aa*aa;
                Vel[j] = Vel[j]*aa2 + w4*aa*ms*G[j];
                tke =  Vel[j]*Vel[j]*Mass[j];
                G[j+1] = (tke - KT)/Mass[j+1];
            }
            Vel[M-1] += w4*G[M-1];
            
            arg = -w4*Vel[0];
            aa = exp(arg);
            aa2 = aa*aa;
            scale *= aa;
            K *= aa2;
        }
        return (scale);
    }
    double Nosethermo::update_nhm_respa(double ke2, double Dt){
        double w2 = 0.5*Dt/(double)Nrespa;
        double w4 = 0.5*w2;
        double arg, aa,aa2;
        double scale = 1.0;
        double tke = ke2;
        for (int i = 0; i < Nrespa; i++){
            for (int k = M-1; k >= 0; k--) {
                arg = w4*Vel[k];
                aa  = exp(-arg);
                scale *= aa;
                tke *= aa*aa;
                G[k] = (tke - KT)/Mass[k];
                Vel[k] += w4*G[k];
            }
            for (int k = 0; k < M; k++)
                Pos[k] += w2*Vel[k];
            
            for (int k = 0; k < M; k++) {
                G[k] = (tke - KT)/Mass[k];
                Vel[k] += w4*G[k];
                arg = w4*Vel[k];
                aa = exp(-arg);
                scale *= aa;
                tke *= aa*aa;
            }
            
        }
        return (scale);
    }
////////////////////////////////////////////////////////////////////////////
                
}

