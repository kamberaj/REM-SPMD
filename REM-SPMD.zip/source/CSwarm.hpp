/* 
 * File:   CSwarm.hpp
 * Author: Hiqmet Kamberaj
 *
 * Created on November 26, 2010, 12:26 PM
 */

#ifndef CSwarm_HPP
#define	CSwarm_HPP

#include <vector>
#include "CParticle.hpp"
#include "Thermostat.hpp"
#include "FFParams.hpp"

using namespace std;
using namespace thermo;
using namespace ffp;

namespace spo {
    class CSwarm {
    public:
        CSwarm();
        CSwarm(int np, int nd, double xmin, double xmax, double dt, int m, double tau, double kt0, double kt, short int qbias);
        CSwarm(const CSwarm& orig);
        virtual ~CSwarm();

        void RandomInitSwarmParticles();
        
        double  getSwarmGlobalBestScore();
        void    setupSwarmGlobalBestPosition();
        vector<double> getSwarmGlobalBestPosition();
        void    deleteSwarmGlobalBestPosition();
        int     getSwarmParticleDimension();
        double  getSwarmDiversity();
        
        void moveNoseThermostatNextStep();
        
        virtual void updateSwarmGlobalBestPosition();
        virtual void moveVelocityNextStep();
        virtual void movePositionNextStep();
        virtual void calcSwarmDiversity();
        virtual void setupSwarmParticles(short int qbias);
        virtual void setupSwarmThermostats(int n, int m, double tau);
        virtual void initSwarmParticles(double mass, bool fileStart);

        int getSwarmThermoDimension();
        void UpdateParticleThermostats(double dt);
        
        vector  <CParticle*> _Particle;
        vector  <Thermostat*> _Thermo;
        
        FFParams _ffp;
        

    protected:
        int     Nparticles;
        int     Nthermos;
        int     Ndim;
        double  Xmax;
        double  Xmin;
        double  Dt;
        double  KT0,KT;
        vector<double>  X_Gbest;
        double  Score_Gbest;
        double  Diversity;
        
    }; // End class Swarm

} // end namespace Spo

#endif	/* CSwarm_HPP */

