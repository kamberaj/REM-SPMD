//
//  BondType.h
//  
//
//  Created by Hiqmet Kamberaj on 30/06/2015.
//
//

#ifndef ____BondType__
#define ____BondType__

#include <vector>

using namespace std;

namespace spo {
    class BondType {
    public:
        BondType();
        BondType(int ndim, int I, int J, double b, double kforce);
        BondType(const BondType& orig);
        virtual ~BondType();
        
        double getBondForceConstant();
        void setBondForceConstant(double f);
        double getEquilBondDistance();
        void setEquilBondDistance(double b);
        double getEnergy();

        void calcBondStretchingGradient(double x1[], double x2[], int dim);
        vector<double> getBondStretchingGradientAtomTypeA();
        vector<double> getBondStretchingGradientAtomTypeB();
        
        void setBondAtomTypeA(char atype[]);
        void setBondAtomTypeB(char atype[]);
        void getBondAtomTypeA(char atype[]);
        void getBondAtomTypeB(char atype[]);
        
        void setBondAtomIndexA(int i);
        int  getBondAtomIndexA();
        void setBondAtomIndexB(int i);
        int  getBondAtomIndexB();
        
        double b0;
        double kb;
        double e;
        vector<double> forceA;
        vector<double> forceB;
        char atomTypeA[4];
        char atomTypeB[4];
        int AtomIndexA;
        int AtomIndexB;
    };

}
#endif /* defined(____BondType__) */
