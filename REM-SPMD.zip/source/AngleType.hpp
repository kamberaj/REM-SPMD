//
//  AngleType.h
//  
//
//  Created by Hiqmet Kamberaj on 30/06/2015.
//
//

#ifndef ____AngleType__
#define ____AngleType__

#include <vector>

using namespace std;

namespace spo {
    class AngleType {
    public:
        AngleType();
        AngleType(int ndim, int I, int J, int K, double theta0, double kforce[]);
        AngleType(const AngleType& orig);
        virtual ~AngleType();
        
        void setAngleForceConstant(double f[]);
        void setEquilAngle(double b);
        double getEnergy();
        
        void calcAngleGradient(double x1[], double x2[], double x3[], int dim);
        vector<double> getAngleGradientAtomTypeA();
        vector<double> getAngleGradientAtomTypeB();
        vector<double> getAngleGradientAtomTypeC();
        
        void setAngleAtomTypeA(char atype[]);
        void setAngleAtomTypeB(char atype[]);
        void setAngleAtomTypeC(char atype[]);
        void getAngleAtomTypeA(char atype[]);
        void getAngleAtomTypeB(char atype[]);
        void getAngleAtomTypeC(char atype[]);
        
        void setAngleAtomIndexA(int i);
        int  getAngleAtomIndexA();
        void setAngleAtomIndexB(int i);
        int  getAngleAtomIndexB();
        void setAngleAtomIndexC(int i);
        int  getAngleAtomIndexC();

        
    private:
        double theta0;
        double ktheta[3];
        double e;
        vector<double> forceA;
        vector<double> forceB;
        vector<double> forceC;
        char atomTypeA[4];
        char atomTypeB[4];
        char atomTypeC[4];
        int AtomIndexA;
        int AtomIndexB;
        int AtomIndexC;
    };
    
}

#endif /* defined(____AngleType__) */
