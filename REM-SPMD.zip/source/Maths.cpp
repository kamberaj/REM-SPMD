/* 
 * File:   Maths.cpp
 * Author: Owner
 * 
 * Created on November 26, 2010, 11:34 AM
 */


#include <cmath>
#include <iostream>
#include <fstream>
#include <sys/time.h>
#include <stdlib.h>
#include <stdio.h>
#include <vector>
#include <cstring>
#include <algorithm>

#include "defs.hpp"
#include "Maths.hpp"

using namespace std;

namespace maths {
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    int _readProteinInfo(FILE *fp) {
        double xc, yc, zc, alpha, beta;
        int natoms;
        char header[80];
        char atom[6];
        char end[3];
        int  i, atindex, t_resid, n;
        char t_atname[6];
        char t_resname[4];
        char t_chainname[2];
        char t_segname[12];
        fscanf(fp,"%s\n",header);
        fscanf(fp,"%d\n",&natoms);
        cout << natoms << endl;
        n=0;
        for (i = 0; i < natoms; i++) {
            //fscanf(fp, "%6s%5d%6s%4s%d%lf%lf%lf%lf%lf%12s\n", atom, &atindex, t_atname, t_resname, &t_resid, &xc, &yc, &zc, &alpha, &beta, t_segname);
            fscanf(fp, "%6s%5d%6s%4s%2s%d%lf%lf%lf%lf%lf%12s\n", atom, &atindex, t_atname, t_resname, t_chainname, &t_resid, &xc, &yc, &zc, &alpha, &beta, t_segname);
            if ( strcmp(atom, "END") == 0 ) return n;
            printf(    "%6s%5d%6s%4s %d %lf %lf %lf %lf %lf%12s\n", atom, atindex,  t_atname, t_resname, t_resid,  xc,  yc,  zc,  alpha,  beta, t_segname);
            if ( strcmp(t_atname, "CA") == 0 ) {
                n++;
            }
        }
        fscanf(fp, "%s\n", end);
        cout << n << endl;
        return n;
    }
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    void _readProteinPdb(FILE *fp, molStruct& molecule) {
        int natoms;
        double xc, yc, zc, alpha, beta;
        char header[80];
        char atom[6];
        char end[3];
        int  i, d, atindex, t_resid;
        char t_atname[6];
        char t_resname[4];
        char t_chainname[2];
        char t_segname[12];
        int ic = 0;
        FILE *fout = fopen("/home/hkamberaj/Documents/soft/DQGSPO/source/utils/struct0.pdb", "w");
        fscanf(fp,"%s\n",header);
        fscanf(fp,"%d\n",&natoms);
        cout << natoms << endl;
        fprintf(fout, "REMARK\n");
        for (i = 0; i < natoms; i++) {
            fscanf(fp, "%6s%5d%6s%4s%2s%d%lf%lf%lf%lf%lf%12s\n", atom, &atindex, t_atname, t_resname, t_chainname, &t_resid, &xc, &yc, &zc, &alpha, &beta, t_segname);
            //fscanf(fp, "%6s%5d%6s%4s%d%lf%lf%lf%lf%lf%12s\n", atom, &atindex, t_atname, t_resname, &t_resid, &xc, &yc, &zc, &alpha, &beta, t_segname);
            if ( strcmp(t_atname, "CA") == 0 ) {
                fprintf(fout, "%6s%5d %4s %3s %s%4d    %8.3f%8.3f%8.3f\n", "ATOM  ", ic+1, "AR  ", "ARG",  "X", ic+1,  xc,  yc,  zc);
                molecule.pAtom[ic].X=xc;
                molecule.pAtom[ic].Y=yc;
                molecule.pAtom[ic].Z=zc;
                strcpy( molecule.pAtom[ic].atname, t_atname );
                strcpy( molecule.pAtom[ic].resname, t_resname );
                strcpy( molecule.pAtom[ic].chainname, t_chainname );
                _toUpper(molecule.pAtom[ic].resname, molecule.pAtom[ic].resname, 4);
                ic++;
            }
        }
        fscanf(fp, "%s\n", end);
        fprintf(fout, "END\n");
        fclose(fout);
    }
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    vector<double> _getTorsionAngles( vector<double>x, int ndim ) {
        vector<double> theta;
        double x1[3],x2[3],x3[3],x4[3];
        int I,J,K,L;
        int natoms = ndim/3;
        double X[natoms];
        double Y[natoms];
        double Z[natoms];
        natoms = 0;
        for (I = 0; I < ndim; I+=3) {
            X[natoms] = x[I];
            Y[natoms] = x[I+1];
            Z[natoms] = x[I+2];
            natoms++;
        }
        for ( I = 0; I < natoms-3; I++ ) {
            J=I+1;
            K=J+1;
            L=K+1;
            x1[0] = X[I];
            x1[1] = Y[I];
            x1[2] = Z[I];
            x2[0] = X[J];
            x2[1] = Y[J];
            x2[2] = Z[J];
            x3[0] = X[K];
            x3[1] = Y[K];
            x3[2] = Z[K];
            x4[0] = X[L];
            x4[1] = Y[L];
            x4[2] = Z[L];
            theta.push_back( _getTorsionTerm(x1, x2, x3, x4, 3) );
        }
        return theta;
    }
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    double _getTorsionTerm(double x1[], double x2[], double x3[], double x4[], int dim){
        double F12[dim];
        double G23[dim];
        double H34[dim];
        double axb[dim];
        double bxc[dim];
        double ra2, rb2;
        double ra2r, rb2r, rabr;
        double ctheta;
        for (int i=0; i < dim; i++) {
            F12[i] = x1[i] - x2[i];
            G23[i] = x2[i] - x3[i];
            H34[i] = x4[i] - x3[i];
        }
        (void) _cross_product(F12, G23, axb);
        (void) _cross_product(G23, H34, bxc);
        ra2 = _dot_product(axb, axb);
        rb2 = _dot_product(bxc, bxc);
        ra2r = 1.0/ra2;
        rb2r = 1.0/rb2;
        rabr = sqrt( ra2r * rb2r );
        // Calculate cos(theta)
        ctheta = _dot_product(axb, bxc) * rabr;
        return acos( ctheta );
    }
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    void _jacobi(int n, int np, double av[], double d[], double vv[]){
        double a[n][n];
        double v[n][n];
        int i, j, k;
        int nrot, maxrot;
        int ip, iq;
        double sm,tresh,s,c,t;
        double theta,tau,h,g,p;
        double b[np],z[np];
        
        // setup calculations
        for (ip = 0, i=0, j=0; ip < (n*n); ip++) {
            a[i][j++] = av[ip];
            if ( j%n == 0 ) {
                j=0;
                i++;
            }
        }
        maxrot=100;
        nrot=0;
        for (ip = 0; ip < n; ip++){
            for (iq = 0; iq < n; iq++){
                v[ip][iq] = 0.0;
            }
            v[ip][ip] = 1.0;
        }
        for (ip = 0; ip < n; ip++) {
            b[ip] = a[ip][ip];
            d[ip] = b[ip];
            z[ip] = 0.0;
        }
        // Jacobi rotations
        for (i = 0; i < maxrot; i++) {
            sm = 0.0;
            for (ip = 0; ip < n-1; ip++) {
                for (iq = ip + 1; iq < n; iq++) {
                    sm += abs(a[ip][iq]);
                }
            }
            if (sm > 1.0e-50) {
                if (i < 3) {
                    tresh = 0.2*sm / (n*n);
                }
                else {
                    tresh = 0.0;
                }
                for (ip = 0; ip < n-1; ip++) {
                    for (iq = ip+1; iq < n; iq++) {
                        g =100.0 * abs(a[ip][iq]);
                        if ( (i>3) && (abs(d[ip])+g == abs(d[ip])) &&  (abs(d[iq])+g ==abs(d[iq])) ) {
                            a[ip][iq] = 0.0;
                        }
                        else if (abs(a[ip][iq]) > tresh) {
                            h = d[iq] - d[ip];
                            if (abs(h)+g == abs(h)) {
                                t = a[ip][iq] / h;
                            }
                            else {
                                theta = 0.5*h/a[ip][iq];
                                t = 1.0 / ( abs(theta) + sqrt(1.0 + theta*theta) );
                                if (theta < 0.0) t = -t;
                            }
                            c = 1.0/sqrt(1.0 + t*t);
                            s = t*c;
                            tau = s / (1.0 + c);
                            h = t * a[ip][iq];
                            z[ip] = z[ip] - h;
                            z[iq] = z[iq] + h;
                            d[ip] = d[ip] - h;
                            d[iq] = d[iq] + h;
                            a[ip][iq] = 0.0;
                            for (j = 0; j < ip - 1; j++) {
                                g = a[j][ip];
                                h = a[j][iq];
                                a[j][ip] = g - s*(h + g*tau);
                                a[j][iq] = h + s*(g - h*tau);
                            }
                            for (j = ip+1; j < iq-1; j++) {
                                g = a[ip][j];
                                h = a[j][iq];
                                a[ip][j] = g - s*(h + g*tau);
                                a[j][iq] = h + s*(g - h*tau);
                            }
                            for (j = iq+1; j < n; j++) {
                                g = a[ip][j];
                                h = a[iq][j];
                                a[ip][j] = g - s*(h + g*tau);
                                a[iq][j] = h + s*(g - h*tau);
                            }
                            for (j = 0; j< n; j++) {
                                g = v[j][ip];
                                h = v[j][iq];
                                v[j][ip] = g - s*(h + g*tau);
                                v[j][iq] = h + s*(g - h*tau);
                            }
                            nrot++;
                        }
                    }
                }
                for (ip = 0; ip < n; ip++){
                    b[ip] = b[ip] + z[ip];
                    d[ip] = b[ip];
                    z[ip] = 0.0;
                }
            }
            else {
                if (nrot  == maxrot) {
                    cout << "Error: JACOBI matrix diagonalization did not converge!" << endl;
                    exit(1);
                }
            }
        }
        if (nrot  == maxrot) {
            cout << "Error: JACOBI matrix diagonalization did not converge!" << endl;
            exit(1);
        }
        // sort the eigenvalues
        for (i = 0; i < n-1; i++) {
            k = i;
            p = d[i];
            for (j = i+1; j < n; j++) {
                if ( d[j] > p ) {
                    k = j;
                    p = d[j];
                }
            }
            if ( k != i) {
                d[k] = d[i];
                d[i] = p;
                for (j=0; j < n; j++) {
                    p = v[j][i];
                    v[j][i] = v[j][k];
                    v[j][k] = p;
                }
            }
        }
        for (ip = 0, i=0, j=0; ip < (n*n); ip++) {
            vv[ip] = v[i][j++];
            if ( j%n == 0 ) {
                j=0;
                i++;
            }
        }
    }
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    double _chirality(vector<double>x, int ndim) {
        double G;
        int N;
        N=ndim/3;
        double X[N];
        double Y[N];
        double Z[N];
        int i, j, k, l;
        N=0;
        for (int i=0; i < ndim; i+=3) {
            X[N] = x[i];
            Y[N] = x[i+1];
            Z[N] = x[i+2];
            N++;
        }
        G=0.0;
        for (i = 0; i < N-3; i++) {
            for (j = i+1; j < N-2; j++) {
                for (k = j+1; k < N-1; k++) {
                    for (l = k+1; l < N; l++) {
                        G += _chirality4(i, j, k, l, X, Y, Z);
                    }
                }
            }
        }
        // Normalize chirality: 10^4 * (4!) / (3 * N^4)
        double norm = 10000.0 * 8.0 / (N*N*N*N);
        G *= norm;
        return G;
    }
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    double _chirality4(int i, int j, int k, int l, double X[], double Y[], double Z[]){
        double G4;
        vector<int> index;
        double rijkl[3], rij[3], rjk[3], ril[3], rkl[3];
        double mag_ril, mag_rij, mag_rjk, mag_rkl;
        double dot_ijjk, dot_jkkl, dot_ijklil;
        index.push_back(i);
        index.push_back(j);
        index.push_back(k);
        index.push_back(l);
        rij[0] = X[index[0]]-X[index[1]];
        rij[1] = Y[index[0]]-Y[index[1]];
        rij[2] = Z[index[0]]-Z[index[1]];
        rjk[0] = X[index[1]]-X[index[2]];
        rjk[1] = Y[index[1]]-Y[index[2]];
        rjk[2] = Z[index[1]]-Z[index[2]];
        ril[0] = X[index[0]]-X[index[3]];
        ril[1] = Y[index[0]]-Y[index[3]];
        ril[2] = Z[index[0]]-Z[index[3]];
        rkl[0] = X[index[2]]-X[index[3]];
        rkl[1] = Y[index[2]]-Y[index[3]];
        rkl[2] = Z[index[2]]-Z[index[3]];
        mag_rij  = _dot_product(rij, rij);
        mag_rjk  = _dot_product(rjk, rjk);
        dot_ijjk = _dot_product(rij, rjk);
        _cross_product(rij, rkl, rijkl);
        dot_jkkl   = _dot_product(rjk, rkl);
        dot_ijklil = _dot_product(rijkl, ril);
        mag_ril    = sqrt( _dot_product(ril, ril) );
        mag_rkl    = _dot_product(rkl, rkl);
        G4 = dot_ijklil * dot_ijjk * dot_jkkl / ( mag_rij * mag_rjk * mag_rkl * mag_ril );
        while ( next_permutation(index.begin(), index.end()) ) {
            rij[0] = X[index[0]]-X[index[1]];
            rij[1] = Y[index[0]]-Y[index[1]];
            rij[2] = Z[index[0]]-Z[index[1]];
            rjk[0] = X[index[1]]-X[index[2]];
            rjk[1] = Y[index[1]]-Y[index[2]];
            rjk[2] = Z[index[1]]-Z[index[2]];
            ril[0] = X[index[0]]-X[index[3]];
            ril[1] = Y[index[0]]-Y[index[3]];
            ril[2] = Z[index[0]]-Z[index[3]];
            rkl[0] = X[index[2]]-X[index[3]];
            rkl[1] = Y[index[2]]-Y[index[3]];
            rkl[2] = Z[index[2]]-Z[index[3]];
            mag_rij = _dot_product(rij, rij);
            mag_rjk  = _dot_product(rjk, rjk);
            dot_ijjk = _dot_product(rij, rjk);
            _cross_product(rij, rkl, rijkl);
            dot_jkkl   = _dot_product(rjk, rkl);
            dot_ijklil = _dot_product(rijkl, ril);
            mag_ril    = sqrt( _dot_product(ril, ril) );
            mag_rkl    = _dot_product(rkl, rkl);
            G4 += dot_ijklil * dot_ijjk * dot_jkkl / ( mag_rij * mag_rjk * mag_rkl * mag_ril );
        }
        index.clear();
        return G4;
    }
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    double _chirality2(vector<double>x, int ndim) {
        double G;
        int N;
        N=ndim/3;
        double X[N];
        double Y[N];
        double Z[N];
        double rijkl[3], rij[3], rjk[3], ril[3], rkl[3];
        double mag_ril, mag_rij, mag_rjk, mag_rkl;
        double dot_ijjk, dot_jkkl, dot_ijklil;
        int i, j, k, l;
        N=0;
        for (int i=0; i < ndim; i+=3) {
            X[N] = x[i];
            Y[N] = x[i+1];
            Z[N] = x[i+2];
            N++;
        }
        G=0.0;
        for (i=0; i < N; i++) {
            for (j=0; j < N; j++) {
                if ( j != i ) {
                    rij[0] = X[i]-X[j];
                    rij[1] = Y[i]-Y[j];
                    rij[2] = Z[i]-Z[j];
                    mag_rij = _dot_product(rij, rij);
                    for (k=0; k < N; k++) {
                        if ( (k != j) && (k != i) ) {
                            rjk[0] = X[j]-X[k];
                            rjk[1] = Y[j]-Y[k];
                            rjk[2] = Z[j]-Z[k];
                            mag_rjk  = _dot_product(rjk, rjk);
                            dot_ijjk = _dot_product(rij, rjk);
                            for (l=0; l < N; l++) {
                                if ( (l != i) && (l != j) && (l != k) ) {
                                    ril[0] = X[i]-X[l];
                                    ril[1] = Y[i]-Y[l];
                                    ril[2] = Z[i]-Z[l];
                                    rkl[0] = X[k]-X[l];
                                    rkl[1] = Y[k]-Y[l];
                                    rkl[2] = Z[k]-Z[l];
                                    _cross_product(rij, rkl, rijkl);
                                    dot_jkkl   = _dot_product(rjk, rkl);
                                    dot_ijklil = _dot_product(rijkl, ril);
                                    mag_ril    = sqrt( _dot_product(ril, ril) );
                                    mag_rkl    = _dot_product(rkl, rkl);
                                    G += dot_ijklil * dot_ijjk * dot_jkkl / ( mag_rij * mag_rjk * mag_rkl * mag_ril );
                                }
                            }
                        }
                    }
                }
            }
        }
        // Normalize chirality: 10^4 * (4!) / (3 * N^4)
        double norm = 10000.0 * 8.0 / (N*N*N*N);
        G *= norm;
        return G;
    }
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    double _radiusGyration(vector<double>x, int ndim) {
        double xc, yc, zc;
        double Rg;
        int N;
        xc=0.0;
        yc=0.0;
        zc=0.0;
        N=0;
        for (int i=0; i < ndim; i+=3) {
            xc += x[i];
            yc += x[i+1];
            zc += x[i+2];
            N++;
        }
        xc /= (double) N;
        yc /= (double) N;
        zc /= (double) N;
        Rg=0.0;
        for (int i=0; i < ndim; i+=3) {
            Rg += (x[i] - xc)*(x[i] - xc) + (x[i+1] - yc)*(x[i+1] - yc) + (x[i+2] - zc)*(x[i+2] - zc);
        }
        Rg /= (double) N;
        Rg = sqrt(Rg);
        return Rg;
    }
 //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    void _gyrationTensorAnalysis(vector<double>x, int ndim, double& Rg, double& ac, double& as, double& rsa) {
        double xc[3];
        double gT[3][3];
        int N;
        int i, j, ip, k;

        for (i=0; i < 3; i++) xc[i] = 0.0;
        N=0;
        for (i=0; i < ndim; i+=3) {
            xc[0] += x[i];
            xc[1] += x[i+1];
            xc[2] += x[i+2];
            N++;
        }
        for (i=0; i < 3; i++) xc[i] /= (double) N;
        for (i=0; i < 3; i++) {
            for (j = 0; j < 3; j++)
                gT[i][j]=0.0;
        }
        for (i=0; i < ndim; i+=3) {
            for (j=0; j < 3; j++) {
                 for (k=0; k < 3; k++)
                     gT[j][k] += (x[i+j] - xc[j]) * (x[i+k] - xc[k]);
            }
        }
        for (i=0; i < 3; i++) {
            for (j = 0; j < 3; j++)
                gT[i][j] /= (double) N;
        }
        double eigval[3];
        double vv[9];
        double av[9];
        double eigvec[3][3];
 
        // copy the matrix
        for (ip = 0, i=0, j=0; ip < 9; ip++) {
            av[ip] = gT[i][j++];
            if ( j%3 == 0 ) {
                j=0;
                i++;
            }
        }
        _jacobi(3,3,av,eigval,vv);
        
        // copy the eigenvector matrix
        for (ip = 0, i=0, j=0; ip < 9; ip++) {
            eigvec[i][j++] = vv[ip];
            if ( j%3 == 0 ) {
                j=0;
                i++;
            }
        }
        Rg  = sqrt( eigval[0] + eigval[1] + eigval[2] );
        as  = eigval[0] - 0.5*(eigval[1] + eigval[2]);
        ac  = eigval[1] - eigval[2];
        rsa = -0.5 + 1.5*(eigval[0]*eigval[0] + eigval[1]*eigval[1] + eigval[2]*eigval[2])/(Rg*Rg*Rg*Rg);
        
    }
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    void _toUpper(char a[], char b[], int n){
        for (int i=0; i < n; i++){
            if (a[i] >= 97 && a[i] <= 122)
                b[i]=static_cast<char>(a[i] - 32);
            else
                b[i ] = a[i];
        }
    }
    void _calcAngle(double a[], double b[], int ndim, double &c, double &s) {
        double aXb[ndim];
        double ab;
        ab = _dot_product(a, b);
        c = ab;
        if (abs(c) > 1.0) c = sign(1.0, c);
        _cross_product(a, b, aXb);
        s = sqrt( _dot_product(aXb, aXb) );
        if (abs(s) > 1.0) s = sign(1.0, s);
    }
    
    /* Return 1 if the difference is negative, otherwise 0.  */
    int _timeval_subtract(struct timeval *result, struct timeval *t2, struct timeval *t1) {
        long int diff = (t2->tv_usec + 1000000 * t2->tv_sec) - (t1->tv_usec + 1000000 * t1->tv_sec);
        result->tv_sec = diff / 1000000;
        result->tv_usec = diff % 1000000;
        
        return (diff<0);
    }
    void _timeval_print(struct timeval *tv) {
        char buffer[30];
        time_t curtime;
        
        printf("Date and Time:  ");
        curtime = tv->tv_sec;
        strftime(buffer, 30, "%m-%d-%Y  %T", localtime(&curtime));
        printf(" = %s.%06d\n", buffer, tv->tv_usec);
    }

    double _average(double x[], int n){
        double a = 0.0;
        for (int i = 0; i < n; i++)
            a += x[i];
        return ( a/((double) n) );
    }

    double sign(double o, double i) {
        if (i < 0.0) {
            return -abs(o);
        }
        else if (i > 0.0) {
            return abs(o);
        }
        else {
            return 0.0;
        }
    }
    
    double lnq(double q, double u) {
        double q1 = 1.0 - q;
        if (abs(q1) <= 1.0e-20) {
            return log(u);
        }
        else {
            double uq = pow(u,q1);
            return ((uq - 1.0)/q1);
        }
    }
    
    void _cross_product(double x[], double y[], double z[]) {
        z[0] =   x[1]*y[2] - x[2]*y[1];
        z[1] = -(x[0]*y[2] - x[2]*y[0]);
        z[2] =   x[0]*y[1] - x[1]*y[0];
    }
    double _dot_product(double x[], double y[]) {
        return (x[0]*y[0] + x[1]*y[1] + x[2]*y[2]);
    }
}


