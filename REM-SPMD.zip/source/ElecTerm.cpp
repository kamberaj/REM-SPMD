//
//  ElecTerm.cpp
//  
//
//  Created by Hiqmet Kamberaj on 01/07/2015.
//
//

#include "ElecTerm.hpp"

#include <iostream>
#include <cmath>
#include <vector>
#include <cstring>

#include "Maths.hpp"
#include "defs.hpp"

using namespace std;
using namespace maths;

namespace spo {
    ElecTerm::ElecTerm() {
    }
    ElecTerm::ElecTerm(int ndim, molStruct molecule, ffDefs _ff) {
        double iCharge, jCharge;
        this->Ndim = ndim;
        int natoms = ndim/3;
        for (int i=0; i < ndim; i++) {
            this->force.push_back(0.0);
        }
        for (int I = 0; I < natoms-3; I++) {
            cout << I << endl;
            if (strcmp(molecule.pAtom[I].resname, "ARG") == 0 ||
                strcmp(molecule.pAtom[I].resname, "HIS") == 0 ||
                strcmp(molecule.pAtom[I].resname, "LYS") == 0) {
                iCharge = scale_charge * sqrt(Unit_of_energy * cal_to_joul);
            }
            else if (strcmp(molecule.pAtom[I].resname, "ASP") == 0 ||
                     strcmp(molecule.pAtom[I].resname, "GLU") == 0) {
                iCharge = -scale_charge * sqrt(Unit_of_energy * cal_to_joul);
            }
            else {
                iCharge = 0.0;
            }
           for (int J = I+3; J < natoms; J++) {
                
                if (strcmp(molecule.pAtom[J].resname, "ARG") == 0 ||
                    strcmp(molecule.pAtom[J].resname, "HIS") == 0 ||
                    strcmp(molecule.pAtom[J].resname, "LYS") == 0) {
                    jCharge = scale_charge * sqrt(Unit_of_energy * cal_to_joul);
                }
                else if (strcmp(molecule.pAtom[J].resname, "ASP") == 0 ||
                         strcmp(molecule.pAtom[J].resname, "GLU") == 0) {
                    jCharge = -scale_charge * sqrt(Unit_of_energy * cal_to_joul);
                }
                else {
                    jCharge = 0.0;
                }
               double eps = 4.0;
               cout << I << "  " << J << "  " << iCharge << "  " << jCharge << endl;
               this->_ElecType.push_back( new ElecType(3, I, J, iCharge, jCharge, eps) );
           }
        }
    }
    ElecTerm::ElecTerm( const ElecTerm& orig ){
    }
    ElecTerm::~ElecTerm(){
    }
    void ElecTerm::calcEnergy(vector<double> X){
        int IA, IB;
        double qij, eps;
        double xa[3], xb[3];
        vector<double> fa, fb;
        int type;
        for (int i=0; i < 3; i++) {
            fa.push_back(0.0);
            fb.push_back(0.0);
        }
// Initialize pot and forces
        this->ElecPot = 0.0;
        for (int i = 0; i < this->Ndim; i++) this->force[i] = 0.0;
        
        for (std::vector<ElecType*>::const_iterator it = _ElecType.begin(); it != _ElecType.end(); ++it) {
            IA = (*it)->getElecAtomIndexA();
            IB = (*it)->getElecAtomIndexB();
            qij= (*it)->getCharge();
            eps= (*it)->getDielectricConstant();
            for (int i = 0; i < 3; i++){
                xa[i] = X[IA*3+i];
                xb[i] = X[IB*3+i];
            }
            (*it)->calcElecGradient(xa, xb, 3, qij, eps);
            fa = (*it)->getElecGradientAtomTypeA();
            fb = (*it)->getElecGradientAtomTypeB();
            for (int i = 0; i < 3; i++){
                this->force[IA*3+i] += fa[i];
                this->force[IB*3+i] += fb[i];
            }
            this->ElecPot += (*it)->getEnergy();
        }
    }
    vector<double> ElecTerm::getForces(){
        return this->force;
    }
    double ElecTerm::getEnergy(){
        return this->ElecPot;
    }
}


