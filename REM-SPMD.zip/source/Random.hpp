/* 
 * File:   Random.hpp
 * Author: Owner
 *
 * Created on November 26, 2010, 11:23 AM
 */

#ifndef RANDOM_HPP
#define	RANDOM_HPP

namespace rangen {

    void initrand();
    int irand();

    int irand(int max);
    int irand(int min, int max);

    float frand();
    float frand(float max);
    float frand(float min, float max);

    double drand();
    double drand(double max);
    double drand(double min, double max);

    double qgrand(double qprime);
    double grand();
    

} // end of namespace random

#endif	/* RANDOM_HPP */

