/* 
 * File:   CParticle.cpp
 * Author: Hiqmet Kamberaj
 * 
 * Created on November 25, 2010, 1:49 PM
 */

#include "CParticle.hpp"
#include "Random.hpp"
#include "Maths.hpp"
#include "defs.hpp"

#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <cmath>
#include <fstream>

using namespace std;
using namespace rangen;
using namespace maths;

namespace spo {

    CParticle::CParticle(double kt, short int qbias) {
        initrand();
        this->Qbias = qbias;
        this->setupWeights(kt);
        this->Score_Lbest = 1.0e+20;
    }

    CParticle::CParticle(int ndim, double kt, short int qbias) {
        initrand();
        this->Qbias = qbias;
        this->setDimension(ndim);
        this->setupWeights(kt);
        this->Score_Lbest = 1.0e+20;
    }

    CParticle::CParticle(const CParticle& orig) {
    }

    CParticle::~CParticle() {
 
    }

    void CParticle::refresh() {
        this->Score_Lbest = 1.0e+20;
        this->deleteParticlePosition();
        this->deleteParticleVel();
    }
    
    void CParticle::setupELECInteractions(int ndim, ffDefs _ffp){
        _elecTerm = new ElecTerm(ndim, this->molecule, _ffp);
    }
    void CParticle::setupVDWInteractions(int ndim, ffDefs _ffp){
        _vdwTerm = new VdwTerm(ndim, this->molecule, _ffp);
    }
    void CParticle::setupBONDInteractions(int ndim, ffDefs _ffp){
        _bondTerm = new BondTerm(ndim, this->molecule, _ffp);
    }
    void CParticle::setupANGLEInteractions(int ndim, ffDefs _ffp){
        _angleTerm = new AngleTerm(ndim, this->molecule, _ffp);
    }
    void CParticle::setupTORSIONInteractions(int ndim, ffDefs _ffp){
        _torsionTerm = new TorsionTerm(ndim, this->molecule, _ffp);
    }
    
   // set and get the  dimension
    void CParticle::setDimension(int ndim){
        this->Ndim = ndim;
    }
    int CParticle::getDimension(){
        return this->Ndim;
    }
    
    void CParticle::initParticleMass(double mass){
        for (int i = 0; i < this->Ndim; ++i)
            this->Mass.push_back(mass);
    }

    vector <double> CParticle::getParticleMass(){
        return this->Mass;
    }
    ////////////////////////////////////////////////////////////////////////////
    void CParticle::RandomInitParticlePosition(double Xmin, double Xmax){
        for (int i = 0; i < this->Ndim; ++i) {
            this->X[i]=drand(0.0,1.0)*(Xmax - Xmin) + Xmin;
        }
    }
    ////////////////////////////////////////////////////////////////////////////
   
    void CParticle::initParticlePosition(double Xmin, double Xmax, ffDefs _ffp, bool fileStart){
        float x, y, z;
        FILE *file;
        if ( fileStart == false ) {
            for (int i = 0; i < this->Ndim; ++i)
                this->X.push_back(drand(0.0,1.0)*(Xmax - Xmin) + Xmin);
        }
        else {
            for (int i = 0; i < this->Ndim; ++i)
                 this->X.push_back(0.0);
            
          
            file = fopen("../source/data/alpha.pdb", "r");
            int nca = _readProteinInfo(file);
            fclose(file);
            
            this->molecule.natoms = nca;
            this->molecule.ndim   = 3;
            this->molecule.pAtom  = new AtomProperty[nca];

            file = fopen("../source/data/alpha.pdb", "r");
            _readProteinPdb(file, this->molecule);
            fclose(file);

            int k = 0;
            for (int i = 0;  i < this->Ndim; i+=3) {
                this->X[i]   = this->molecule.pAtom[k].X;
                this->X[i+1] = this->molecule.pAtom[k].Y;
                this->X[i+2] = this->molecule.pAtom[k].Z;
                cout << "Coordinates    " << k+1 << "  " << this->X[i] << "  " << this->X[i+1] << "  " << this->X[i+2] << endl;
                k++;
            }
        }
        cout << "Setup ELEctrostatic Interactions " << endl;
        this->setupELECInteractions(this->Ndim, _ffp);
        cout << "Setup Van Der Waals Interactions " << endl;
        this->setupVDWInteractions(this->Ndim, _ffp);
        cout << "Setup Bond Stretching Interactions " << endl;
        this->setupBONDInteractions(this->Ndim, _ffp);
        cout << "Setup Angle Bending Interactions " << endl;
        this->setupANGLEInteractions(this->Ndim, _ffp);
        cout << "Setup Dihedral Angle Interactions " << endl;
        this->setupTORSIONInteractions(this->Ndim, _ffp);
        cout << "... done with Interactions " << endl;
    }

    void CParticle::updateParticlePosition(vector<double> X_Gbest, double dt){
        for (int i = 0; i < this->getDimension(); ++i) {
            this->X[i] += dt*this->V[i];
        }
    }
    vector<double> CParticle::getParticlePosition(){
        return this->X;
    }
    void CParticle::printParticlePosition(){
        for (int i=0; i < this->Ndim; i++)
            cout << i << "   " << this->X[i] << endl;
    }
    void CParticle::deleteParticlePosition(){
        this->X.erase(this->X.begin(), this->X.end());
    }
    /////////////////////////////////////////////////////////////////////////////
    void CParticle::setupDihedralAngles(){
        for (int i = 0; i < this->getDimension()/3; i+=4){
            this->DiheAngles.push_back(0.0);
        }
    }
    void CParticle::calcDihedralAngles(){
        this->setDihedralAngles(_getTorsionAngles(this->X, this->Ndim));
    }
    void CParticle::setDihedralAngles(vector<double> r){
        int k=0;
        for (int i = 0; i < this->getDimension()/3; i+=4){
            this->DiheAngles[k]=r[k];
            k++;
        }
    }
    vector<double> CParticle::getDihedralAngles(){
        return this->DiheAngles;
    }
    /////////////////////////////////////////////////////////////////////////////
    void CParticle::calcChirality(){
        this->setChirality(_chirality(this->X, this->Ndim));
    }
    void CParticle::setChirality(double r){
        this->Chirality = r;
    }
    double CParticle::getChirality(){
        return this->Chirality;
    }
    /////////////////////////////////////////////////////////////////////////////
    void CParticle::calcRadiusGyration(){
        this->setRadiusGyration(_radiusGyration(this->X, this->Ndim));
    }
    void CParticle::setRadiusGyration(double r){
        this->RadiusGyration = r;
    }
    double CParticle::getRadiusGyration(){
        return this->RadiusGyration;
    }

    void CParticle::setRelativeShapeAnisotropy(double r){
        this->ShapeAnisotropy = r;
    }
    double CParticle::getRelativeShapeAnisotropy(){
        return this->ShapeAnisotropy;
    }

    void CParticle::setAhelicity(double r){
        this->Ahelicity = r;
    }
    double CParticle::getAhelicity(){
        return this->Ahelicity;
    }
    void CParticle::setAsphericity(double r){
        this->Asphericity = r;
    }
    double CParticle::getAsphericity(){
        return this->Asphericity;
    }

    void CParticle::doGyrationTensorAnalysis(){
        double Rg, ac, as, rsa;
        _gyrationTensorAnalysis(this->X, this->Ndim, Rg, ac, as, rsa);
        this->setRadiusGyration(Rg);
        this->setRelativeShapeAnisotropy(rsa);
        this->setAhelicity(ac);
        this->setAsphericity(as);
    }

    /////////////////////////////////////////////////////////////////////////////
    vector<double> CParticle::getParticleForce(){
        return this->Force;
    }
    void CParticle::setParticleForce(double force[]){
        for (int i = 0; i < this->getDimension(); ++i){
            this->Force[i] = force[i];
        }
    }
    void CParticle::initParticleForce(){
        for (int i = 0; i < this->getDimension(); ++i)
            this->Force.push_back(0.0);
    }
    void CParticle::deleteParticleForce(){
        this->Force.erase(this->Force.begin(), this->Force.end());
    }
    
    ////////////////////////////////////////////////////////////////////////////
    void CParticle::setupWeights(double kt) {
        double gamma;
        if (this->Qbias == 1)
            gamma = 0.1/kt;
        else
            gamma = 0.0;
        
        this->Weight = gamma;
    }
   
   /////////////////////////////////////////////////////////////////////////////
    void CParticle::initParticleVel(double kt){
        for (int i = 0; i < this->Ndim; ++i) {
              this->V.push_back( sqrt(kt/this->Mass[i]) * grand() );
        }
        double mom_x = 0.0;
        double mom_y = 0.0;
        double mom_z = 0.0;
        double tmass = 0.0;
        for (int i = 0; i < this->Ndim; i += 3) {
            mom_x += this->V[i]   * this->Mass[i];
            mom_y += this->V[i+1] * this->Mass[i+1];
            mom_z += this->V[i+2] * this->Mass[i+2];
            tmass += this->Mass[i];
        }
        mom_x /= tmass;
        mom_y /= tmass;
        mom_z /= tmass;
        for (int i = 0; i < this->Ndim; i += 3) {
            this->V[i]   -= mom_x;
            this->V[i+1] -= mom_y;
            this->V[i+2] -= mom_z;
        }
    }
    void CParticle::updateParticleVel(vector<double> X_Gbest, double dt){
        double hdt = 0.5*dt;
        double Force_bias;
        double ubias = 0.0;
        double term1, term2, u1, u2;
        for (int i = 0; i < this->getDimension(); ++i) {
            u1 = drand(0.0,1.0);
            u2 = drand(0.0,1.0);
            term1 = this->X_Lbest[i] - this->X[i];
            term2 = X_Gbest[i]       - this->X[i];
            
            Force_bias = this->Weight*( u1*term1 + u2*term2 );
            this->V[i] += hdt*(this->Force[i]/this->Mass[i]) + hdt*(Force_bias/this->Mass[i]);
            
            ubias += this->Weight*( u1*term1*term1 + u2*term2*term2 );
        }
        this->setParticleBiasEnergy(0.5*ubias);
    }
    void CParticle::setParticleBiasEnergy(double ub) {
        this->Ubias = ub;
    }
    double CParticle::getParticleBiasEnergy() {
        return this->Ubias;
    }
    vector<double> CParticle::getParticleVel(){
        return this->V;
    }
    void CParticle::deleteParticleVel(){
        this->V.erase(this->V.begin(), this->V.end());
    }
    void CParticle::scaleParticleVel(double s){
        for (int i = 0; i < this->getDimension(); ++i) {
            this->V[i] *= s;
        }
    }
    void CParticle::setParticleVel(vector <double> v){
        for (int i = 0; i < this->getDimension(); ++i){
            this->V[i] = v[i];
        }
    }
    ////////////////////////////////////////////////////////////////////////////
    
    void CParticle::setupLocalBestParticlePosition() {
         for (int i = 0; i < this->Ndim; ++i)
            this->X_Lbest.push_back(0.0);
    }
    void CParticle::updateLocalBestParticlePosition() {
        if (this->Score < this->Score_Lbest) {
            this->Score_Lbest = this->Score;
            for (int i=0; i < this->getDimension(); ++i) {
                this->X_Lbest[i] = this->X[i];
            }
        }
    }
    vector<double> CParticle::getLocalBestParticlePosition(){
        return this->X_Lbest;
    }
    double CParticle::getLocalBestParticlePositionIndex(int i){
        return this->X_Lbest[i];
    }
    void CParticle::deleteLocalBestParticlePosition() {
        this->X_Lbest.erase(this->X_Lbest.begin(), this->X_Lbest.end());
    }

    ////////////////////////////////////////////////////////////////////////////

    double CParticle::getParticleBestScore() {
        return (this->Score_Lbest);
    }
    double CParticle::getParticleScore() {
        return (this->Score);
    }
    void CParticle::setParticleScore(double score) {
        this->Score = score;
    }
   
    ////////////////////////////////////////////////////////////////////////////
    
    double CParticle::getParticleKineticEnergy() {
        return (this->Ekin);
    }
    void CParticle::setParticleKineticEnergy(double e) {
        this->Ekin = e;
    }
    void CParticle::calcParticleKineticEnergy() {
        double e = 0.0;
        for (int i = 0; i < Ndim; ++i){
            e += Mass[i]*this->V[i]*this->V[i];
        }
        e *= 0.5;
        this->setParticleKineticEnergy(e);
    }
    ////////////////////////////////////////////////////////////////////////////

    double CParticle::getParticleHamiltonian() {
        return (this->Ham);
    }
    void CParticle::setParticleHamiltonian(double e) {
        this->Ham = e;
    }
    void CParticle::calcParticleHamiltonian() {
        this->setParticleHamiltonian(this->getParticleScore()+this->getParticleKineticEnergy());
    }
    ////////////////////////////////////////////////////////////////////////////

}

