//
//  TorsionTerm.h
//  
//
//  Created by Hiqmet Kamberaj on 01/07/2015.
//
//

#ifndef ____TorsionTerm__
#define ____TorsionTerm__

#include <vector>

#include "TorsionType.hpp"
#include "defs.hpp"


using namespace std;

namespace spo {
    class TorsionTerm {
    public:
        TorsionTerm();
        TorsionTerm(int ndim, molStruct molecule, ffDefs _ffp);
        TorsionTerm(const TorsionTerm& orig);
        virtual ~TorsionTerm();
        
        vector <TorsionType*> _TorsionType;
        
        void calcEnergy(vector<double> X);
        vector<double> getForces();
        double getEnergy();
        double getTorsionAngle(double x1[], double x2[], double x3[], double x4[], int dim);
        
    private:
        int Ndim;
        double TorsionPot;
        vector<double> force;
    };
}
#endif /* defined(____TorsionTerm__) */
