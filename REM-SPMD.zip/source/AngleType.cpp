//
//  AngleType.cpp
//  
//
//  Created by Hiqmet Kamberaj on 30/06/2015.
//
//

#include "AngleType.hpp"

#include <iostream>
#include <cmath>
#include <cstring>
#include <vector>
#include "Maths.hpp"

using namespace std;
using namespace maths;

namespace spo {
    AngleType::AngleType() {
    }
    AngleType::AngleType(int ndim, int I, int J, int K, double theta0, double kforce[]) {
        for (int i=0; i < ndim; i++) {
            this->forceA.push_back(0.0);
            this->forceB.push_back(0.0);
            this->forceC.push_back(0.0);
            setAngleAtomIndexA(I);
            setAngleAtomIndexB(J);
            setAngleAtomIndexC(K);
            
            setEquilAngle(theta0);
            setAngleForceConstant(kforce);
        }
    }
    AngleType::AngleType(const AngleType& orig){
    }
    AngleType::~AngleType(){
    }
    void AngleType::setAngleForceConstant(double k[]){
        this->ktheta[0] = k[0];
        this->ktheta[1] = k[1];
        this->ktheta[2] = k[2];
    }
    void AngleType::setEquilAngle(double theta){
        this->theta0 = theta;
    }
    double AngleType::getEnergy(){
        return this->e;
    }
    void AngleType::calcAngleGradient(double x1[], double x2[], double x3[], int dim){
        double r12[dim], r32[dim];
        double DF1[dim], DF3[dim];
        double rp[dim], rijXrp[dim], rkjXrp[dim];
        double ctheta, rij, rij2, rkj, rkj2, rijr, rkjr;
        double terma, termc;
        rij2 = 0.0;
        rkj2 = 0.0;
        for (int i=0; i < dim; i++) {
            r12[i] = x1[i] - x2[i];
            r32[i] = x3[i] - x2[i];
            rij2 += (r12[i] * r12[i]);
            rkj2 += (r32[i] * r32[i]);
        }
        if ( abs(rij2) >= 1.0e-10 && abs(rkj2) >= 1.0e-10 ) {
            rij = sqrt( rij2 );
            rkj = sqrt( rkj2 );
            rijr = 1.0/rij;
            rkjr = 1.0/rkj;
            double dot = _dot_product(r12, r32);
            ctheta = dot * (rijr * rkjr);
            if ( abs(ctheta) > 1.0) ctheta = sign(1.0, ctheta);
        
        // Calculate energy
            double theta = acos( ctheta );
            double da    = theta - this->theta0;
            double da2 = da * da;
            double da3 = da2 * da;
            double da4 = da3 * da;
            this->e  = this->ktheta[0] * da2 + this->ktheta[1] * da3 + this->ktheta[2] * da4;
        
            double df = -(this->ktheta[0] * da * 2.0 + this->ktheta[1] * da2 * 3.0 + this->ktheta[2] * da3 * 4.0);

        // Calculate forces
            _cross_product(r32, r12, rp);
            dot = _dot_product(rp, rp);
            dot = sqrt( dot );

            terma = -df / (rij2 * dot);
            _cross_product(r12, rp, rijXrp);
            for (int i=0; i < dim; i++) DF1[i] = terma * rijXrp[i];

            termc = df / (rkj2 * dot);
            _cross_product(r32, rp, rkjXrp);
            for (int i=0; i < dim; i++) DF3[i] = termc * rkjXrp[i];
            
            for (int i=0; i < dim; i++){
                this->forceA[i] =   DF1[i];
                this->forceB[i] = -(DF1[i] + DF3[i]);
                this->forceC[i] =   DF3[i];
            }
        }
    }
    
    vector<double> AngleType::getAngleGradientAtomTypeA(){
        return this->forceA;
    }
    vector<double> AngleType::getAngleGradientAtomTypeB(){
        return this->forceB;
    }
    vector<double> AngleType::getAngleGradientAtomTypeC(){
        return this->forceC;
    }
    
    void AngleType::setAngleAtomTypeA(char atype[]){
        strcpy(this->atomTypeA, atype);
    }
    void AngleType::getAngleAtomTypeA(char atype[]){
        strcpy(atype, this->atomTypeA);
    }
    
    void AngleType::setAngleAtomTypeB(char atype[]){
        strcpy(this->atomTypeB, atype);
    }
    void AngleType::getAngleAtomTypeB(char atype[]){
        strcpy(atype, this->atomTypeB);
    }
    
    void AngleType::setAngleAtomTypeC(char atype[]){
        strcpy(this->atomTypeC, atype);
    }
    void AngleType::getAngleAtomTypeC(char atype[]){
        strcpy(atype, this->atomTypeC);
    }
    
    void AngleType::setAngleAtomIndexA(int i){
        AtomIndexA = i;
    }
    int AngleType::getAngleAtomIndexA(){
        return this->AtomIndexA;
    }
    
    void AngleType::setAngleAtomIndexB(int i){
        AtomIndexB = i;
    }
    int AngleType::getAngleAtomIndexB(){
        return this->AtomIndexB;
    }
    
    void AngleType::setAngleAtomIndexC(int i){
        AtomIndexC = i;
    }
    int AngleType::getAngleAtomIndexC(){
        return this->AtomIndexC;
    }

}
