/* 
 * File:   CParticle.hpp
 * Author: Hiqmet Kamberaj
 *
 * Created on November 25, 2010, 1:49 PM
 */

#ifndef CPARTICLE_HPP
#define	CPARTICLE_HPP

#include <vector>
#include "ElecTerm.hpp"
#include "VdwTerm.hpp"
#include "BondTerm.hpp"
#include "AngleTerm.hpp"
#include "TorsionTerm.hpp"
#include "defs.hpp"

using namespace std;

namespace spo {
   /**
   * @class CParticle
   * Classical  Particle optimization
   * @note Hiqmet Kamberaj, JCP, 2010, in preparation
   */
    class CParticle {

    public:
        CParticle(double kt, short int qbias);
        CParticle(int n, double kt, short int qbias);
        CParticle(const CParticle& orig);
        virtual ~CParticle();
 
        void RandomInitParticlePosition(double Xmin, double Xmax);
        
        int getDimension();
        void setDimension(int n);

        void initParticleMass(double mass);
        vector <double> getParticleMass();
        
        void initParticleForce();
        vector<double> getParticleForce();
        void setParticleForce(double force[]);
        void deleteParticleForce();
        
        void initParticlePosition(double Xmin, double Xmax, ffDefs _ffp, bool fileStart);
        virtual void updateParticlePosition(vector<double> X_Gbest, double dt);
        vector<double> getParticlePosition();
        void printParticlePosition();

        double getParticlePositionIndex(int i);
        void deleteParticlePosition();
        
        void setParticleVel(vector <double> v);
        void initParticleVel(double kt);
        void scaleParticleVel(double scale);
        void updateParticleVel(vector<double> X_Gbest, double dt);
        vector<double> getParticleVel();
        void deleteParticleVel();
 
        
        void setParticleKineticEnergy(double e);
        double getParticleKineticEnergy();
        void calcParticleKineticEnergy();

        void setParticleHamiltonian(double e);
        double getParticleHamiltonian();
        void calcParticleHamiltonian();
        
        void setParticleScore(double score);
        double getParticleScore();
        double getParticleBestScore();

        void setupLocalBestParticlePosition();
        void updateLocalBestParticlePosition();
        vector<double> getLocalBestParticlePosition();
        double getLocalBestParticlePositionIndex(int i);
        void deleteLocalBestParticlePosition();
      
        void setupELECInteractions(int n, ffDefs _ffp);
        void setupVDWInteractions(int n, ffDefs _ffp);
        void setupBONDInteractions(int n, ffDefs _ffp);
        void setupANGLEInteractions(int n, ffDefs _ffp);
        void setupTORSIONInteractions(int n, ffDefs _ffp);
        
  
        void setParticleBiasEnergy(double ub);
        double getParticleBiasEnergy();

        void   calcRadiusGyration();
        void   setRadiusGyration(double r);
        double getRadiusGyration();
        
        
        void   calcChirality();
        void   setChirality(double r);
        double getChirality();
        
        
        void setupDihedralAngles();
        void calcDihedralAngles();
        void setDihedralAngles(vector<double> r);
        vector<double> getDihedralAngles();
        
        void   setRelativeShapeAnisotropy(double r);
        double getRelativeShapeAnisotropy();
        void   setAhelicity(double r);
        double getAhelicity();
        void   setAsphericity(double r);
        double getAsphericity();
        void   doGyrationTensorAnalysis();

            
        virtual void refresh();
        virtual void setupWeights(double kt);


        VdwTerm* _vdwTerm;
        ElecTerm* _elecTerm;
        BondTerm* _bondTerm;
        AngleTerm* _angleTerm;
        TorsionTerm* _torsionTerm;
        
        int    Ndim;
        double Score;
        double Ekin;
        double Ham;
        vector<double> Mass;
        double Score_Lbest;
        vector<double> X;
        vector<double> V;
        vector<double> Force;
        vector<double> X_Lbest;
        molStruct molecule;


    private:
        double  Weight;
        short int Qbias;
        double Ubias;
        double RadiusGyration;
        double Chirality;
        double Asphericity;
        double Ahelicity;
        double ShapeAnisotropy;
        vector<double> DiheAngles;
    };
}

#endif	/* CPARTICLE_HPP */

