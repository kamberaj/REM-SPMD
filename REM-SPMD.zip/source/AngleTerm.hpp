//
//  AngleTerm.h
//  
//
//  Created by Hiqmet Kamberaj on 01/07/2015.
//
//

#ifndef ____AngleTerm__
#define ____AngleTerm__

#include <vector>

#include "AngleType.hpp"
#include "defs.hpp"


using namespace std;


namespace spo {
    class AngleTerm {
    public:
        AngleTerm();
        AngleTerm(int ndim, molStruct molecule, ffDefs _ffp);
        AngleTerm(const AngleTerm& orig);
        virtual ~AngleTerm();
        
        vector <AngleType*> _AngleType;
    
        
        void calcEnergy(vector<double> X);
        vector<double> getForces();
        double getEnergy();
        double getAngle(double x1[], double x2[], double x3[], int dim);
        
        
    private:
        int Ndim;
        double AnglePot;
        vector<double> force;
    };
}
#endif /* defined(____AngleTerm__) */
