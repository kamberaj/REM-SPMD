//
//  VdwType.cpp
//  
//
//  Created by Hiqmet Kamberaj on 30/06/2015.
//
//

#include "VdwType.hpp"

#include <iostream>
#include <cmath>
#include <cstring>
#include <vector>

#include "Maths.hpp"

using namespace std;
using namespace maths;

namespace spo {
    VdwType::VdwType() {
    }
    VdwType::VdwType(int ndim, int I, int J, double rmin, double eps, double alpha, int type) {
        for (int i=0; i < ndim; i++) {
            this->forceA.push_back(0.0);
            this->forceB.push_back(0.0);
        }
        setVdwPotDepth(eps);
        setVdwRmin(rmin);
        setVdwAlpha(alpha);
        
        setVdwAtomIndexA(I);
        setVdwAtomIndexB(J);
        setVdwType(type);
        
    }
    VdwType::VdwType(const VdwType& orig){
    }
    VdwType::~VdwType(){
    }
    void VdwType::setVdwType(int type){
        this->vdwType = type;
    }
    int VdwType::getVdwType(){
        return this->vdwType;
    }
    double VdwType::getVdwPotDepth(){
        return this->epsilon;
    }
    void VdwType::setVdwPotDepth(double eps){
        this->epsilon = eps;
    }
    double VdwType::getVdwAlpha(){
        return this->Alpha;
    }
    void VdwType::setVdwAlpha(double a){
        this->Alpha = a;
    }
    double VdwType::getVdwRmin(){
        return this->Rmin;
    }
    void VdwType::setVdwRmin(double rmin){
        this->Rmin = rmin;
    }
    double VdwType::getEnergy(){
        return this->e;
    }
    void VdwType::calcVdwGradient(double x1[], double x2[], int dim, double eps, double rmin, double alpha, int type){
        double dx[dim];
        double r, r2, r2r;
        double r6, r8, r10, r12, ex, ex2;
        r2 = 0.0;
        for (int i=0; i < dim; i++) {
            dx[i] = x1[i] - x2[i];
            r2   += dx[i] * dx[i];
        }
        if (r2 <= cutoff2) {
            r2r = 1.0 /r2;
        
            if (type == 1 || type == 2) {
                r6   = pow(rmin*rmin*r2r, 3.0);
                r8   = r6 * r2;
                r10  = r8 * r2;
                r12  = r6 * r6;
            }
            else {
                r   = sqrt( r2 );
                ex  = 1.0 - exp( -alpha * (r - rmin) );
                ex2 = ex * ex;
            }
            if (type == 1) {
                this->e = eps * (5.0 * r12 - 6.0 * r10);
                for (int i=0; i < dim; i++){
                    this->forceA[i] = -60.0 * eps * ( -r12 + r10 ) * dx[i] * r2;
                    this->forceB[i] =  60.0 * eps * ( -r12 + r10 ) * dx[i] * r2;
                }
            }
            else if (type == 2){
                this->e = eps * r12;
                for (int i=0; i < dim; i++){
                    this->forceA[i] = -12.0 * eps * ( -r12 ) * dx[i] * r2;
                    this->forceB[i] =  12.0 * eps * ( -r12 ) * dx[i] * r2;
                }
            }
            else if (type == 3) {
                this->e = eps * (ex2 - 1.0);
                double dudr = 2.0 * eps * alpha * ex * (1.0 - ex);
                for (int i=0; i < dim; i++){
                    this->forceA[i] = -dudr * dx[i] / r;
                    this->forceB[i] =  dudr * dx[i] / r;
                }
            }
            else {
                cout << "Vdw type of interactions not supported!! " << endl;
                exit(1);
            }
        }
    }
    vector<double> VdwType::getVdwGradientAtomTypeA(){
        return this->forceA;
    }
    vector<double> VdwType::getVdwGradientAtomTypeB(){
        return this->forceB;
    }
    
    void VdwType::setVdwAtomTypeA(char atype[]){
        strcpy(this->atomTypeA, atype);
    }
    void VdwType::getVdwAtomTypeA(char atype[]){
        strcpy(atype, this->atomTypeA);
    }
    void VdwType::setVdwAtomTypeB(char atype[]){
        strcpy(this->atomTypeB, atype);
    }
    void VdwType::getVdwAtomTypeB(char atype[]){
        strcpy(atype, this->atomTypeB);
    }


    void VdwType::setVdwAtomIndexA(int i){
        AtomIndexA = i;
    }
    int VdwType::getVdwAtomIndexA(){
        return this->AtomIndexA;
    }
    
    void VdwType::setVdwAtomIndexB(int i){
        AtomIndexB = i;
    }
    int VdwType::getVdwAtomIndexB(){
        return this->AtomIndexB;
    }


}

