//
//  BondTerm.h
//  
//
//  Created by Hiqmet Kamberaj on 01/07/2015.
//
//

#ifndef ____BondTerm__
#define ____BondTerm__

#include <vector>

#include "BondType.hpp"
#include "defs.hpp"


using namespace std;

namespace spo {
    class BondTerm {
    public:
        BondTerm();
        BondTerm(int ndim, molStruct molecule, ffDefs _ffp);
        BondTerm(const BondTerm& orig);
        virtual ~BondTerm();
        
        vector <BondType*> _BondType;
        
        double getBondLength(double x1[], double x2[], int dim);
        void calcEnergy(vector<double> X);
        vector<double> getForces();
        double getEnergy();
        void getBond(double x1[], double x2[], int dim);
        
    private:
        int Ndim;
        double BondPot;
        vector<double> force;
    };
}
#endif /* defined(____BondTerm__) */
