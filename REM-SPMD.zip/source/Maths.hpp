/* 
 * File:   Maths.hpp
 * Author: Hiqmet Kamberaj
 *
 * Created on November 26, 2010, 11:34 AM
 */

#ifndef MATHS_HPP
#define	MATHS_HPP

#include <fstream>
#include <sys/time.h>
#include <stdlib.h>
#include <stdio.h>
#include <vector>

#include "defs.hpp"

namespace maths {
    double sign(double o, double i);
    double lnq(double q, double u);
    double _average(double x[], int n);
    void _cross_product(double x[], double y[], double z[]);
    double _dot_product(double x[], double y[]);
    int _timeval_subtract(struct timeval *result, struct timeval *t2, struct timeval *t1);
    void _timeval_print(struct timeval *tv);
    void _calcAngle(double a[], double b[], int ndim, double &c, double &s);
    void _readProteinPdb(FILE *fp, molStruct& molecule);
    void _toUpper(char a[], char b[], int n);
    int _readProteinInfo(FILE *fp);
    double _radiusGyration(std::vector<double>x, int N);
    double _chirality(std::vector<double>x, int ndim);
    double _chirality2(std::vector<double>x, int ndim);
    double _chirality4(int i, int j, int k, int l, double X[], double Y[], double Z[]);
    void _jacobi(int n, int np, double av[], double d[], double vv[]);
    void _gyrationTensorAnalysis(std::vector<double>x, int ndim, double& Rg, double& ac, double& as, double& rsa);
    std::vector<double> _getTorsionAngles( std::vector<double>x, int ndim );
    double _getTorsionTerm(double x1[], double x2[], double x3[], double x4[], int dim);
}

#endif	/* MATHS_HPP */

