//
//  BondType.cpp
//  
//
//  Created by Hiqmet Kamberaj on 30/06/2015.
//
//

#include "BondType.hpp"

#include <iostream>
#include <cmath>
#include <cstring>
#include <vector>

using namespace std;

#include "Maths.hpp"
using namespace maths;

namespace spo {
    BondType::BondType() {
    }
    BondType::BondType(int ndim, int I, int J, double b, double kforce) {
        for (int i=0; i < ndim; i++) {
            this->forceA.push_back(0.0);
            this->forceB.push_back(0.0);
        }
        setBondAtomIndexA(I);
        setBondAtomIndexB(J);
        this->setBondForceConstant(kforce);
        this->setEquilBondDistance(b);
    }
    BondType::BondType(const BondType& orig){
    }
    BondType::~BondType(){
    }
    double BondType::getBondForceConstant(){
        return this->kb;
    }
    void BondType::setBondForceConstant(double k){
        this->kb = k;
    }
    double BondType::getEquilBondDistance(){
        return this->b0;
    }
    void BondType::setEquilBondDistance(double b){
        this->b0 = b;
    }
    double BondType::getEnergy(){
        return this->e;
    }
    void BondType::calcBondStretchingGradient(double x1[], double x2[], int dim){
        double b2 = 0.0;
        double dx[dim];
        for (int i = 0; i < dim; i++) {
            dx[i] = x1[i] - x2[i];
            b2   += dx[i] * dx[i];
        }
        double b  = sqrt( b2 );
        this->e   = this->kb * (b - b0)*(b - b0);
        double df = -2.0 * this->kb * (b - b0) / b;
        for (int i = 0; i < dim; i++){
            this->forceA[i] =  df * dx[i];
            this->forceB[i] = -df * dx[i];
        }
    }
    vector<double> BondType::getBondStretchingGradientAtomTypeA(){
        return this->forceA;
    }
    vector<double> BondType::getBondStretchingGradientAtomTypeB(){
        return this->forceB;
    }
    
    void BondType::setBondAtomTypeA(char atype[]){
        strcpy(this->atomTypeA, atype);
    }
    void BondType::getBondAtomTypeA(char atype[]){
        strcpy(atype, this->atomTypeA);
    }
    void BondType::setBondAtomTypeB(char atype[]){
        strcpy(this->atomTypeB, atype);
    }
    void BondType::getBondAtomTypeB(char atype[]){
        strcpy(atype, this->atomTypeB);
    }
    
    void BondType::setBondAtomIndexA(int i){
        AtomIndexA = i;
    }
    int BondType::getBondAtomIndexA(){
        return this->AtomIndexA;
    }
    
    void BondType::setBondAtomIndexB(int i){
        AtomIndexB = i;
    }
    int BondType::getBondAtomIndexB(){
        return this->AtomIndexB;
    }

}
