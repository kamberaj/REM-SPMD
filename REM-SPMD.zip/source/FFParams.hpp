//
//  FFParams.h
//  
//
//  Created by Hiqmet Kamberaj on 01/07/2015.
//
//

#ifndef ____FFParams__
#define ____FFParams__

#include <fstream>
#include "defs.hpp"

using namespace std;

namespace ffp {
    class FFParams {
    public:
        FFParams();
        FFParams(FILE *fp);
        FFParams(const FFParams& orig);
        virtual ~FFParams();
        
        void readFFparam(FILE *fp);
        ffDefs getFFParams();
        
        ffDefs ff;
        
    };
}
#endif /* defined(____FFParams__) */
