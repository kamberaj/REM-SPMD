/* 
 * File:   Random.cpp
 * Author: Hiqmet Kamberaj
 * 
 * Created on November 25, 2010, 3:04 PM
 */

#include "Random.hpp"
#include "Maths.hpp"

#include <iostream>
#include <ctime>
#include <cstdlib>
#include <cmath>

using namespace maths;
using namespace std;

namespace rangen {
    
    int firstRand;

    void initrand() {
        srand((unsigned)(time(0)));
        firstRand=1;
    }

    int irand() {
        return rand();
    }

    int irand(int max) {
        return int(max*rand()/(RAND_MAX+1.0));
    }

    int irand(int min, int max) {
        if (min>max) {
            return max+int((min-max+1)*rand()/(RAND_MAX+1.0));
        }
        else {
            return min+int((max-min+1)*rand()/(RAND_MAX+1.0));
        }
    }

    float frand() {
        return rand()/(float(RAND_MAX)+1);
    }

    float frand(float max) {
        return frand()*max;
    }

    float frand(float min, float max) {
        if (min>max) {
            return frand()*(min-max)+max;
        }
        else {
            return frand()*(max-min)+min;
        }
    }

    double drand() {
        return rand()/(double(RAND_MAX)+1);
    }

    double drand(double max) {
        return drand()*max;
    }

    double drand(double min, double max) {
        if (min>max) {
            return drand()*(min-max)+max;
        }
        else {
            return drand()*(max-min)+min;
        }
    }
    
    double qgrand(double qprime) {
        static int iFlag=0;
        if (qprime < 3.0) {
            double q = (1.0 + qprime) / (3.0 - qprime);
            if (iFlag == 0) {
                iFlag=1;
                return sqrt(-2.0*lnq(q,drand())) * cos(2.0*M_PI*drand());
            }
            else if (iFlag == 1) {
                iFlag=0;
                return sqrt(-2.0*lnq(q,drand())) * sin(2.0*M_PI*drand());
            }
        }
        else {
            cerr << "Abort: out of range value of q-Tsallis:  " <<
                    qprime << endl;
            exit(0);
        }
    }

    double grand() {
        static int iFlag=0;
        if (iFlag == 0) {
           iFlag=1;
           return sqrt(-2.0*log(drand())) * cos(2.0*M_PI*drand());
        }
        else if (iFlag == 1) {
           iFlag=0;
           return sqrt(-2.0*log(drand())) * sin(2.0*M_PI*drand());
        }
    }


} // end of namespace random

