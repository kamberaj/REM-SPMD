//
//  VdwType.h
//  
//
//  Created by Hiqmet Kamberaj on 30/06/2015.
//
//

#ifndef ____VdwType__
#define ____VdwType__

#include <vector>

using namespace std;

namespace spo {
    class VdwType {
    public:
        VdwType();
        VdwType(int ndim, int I, int J, double rmin, double eps, double alpha, int type);
        VdwType(const VdwType& orig);
        virtual ~VdwType();
        
        void setVdwType(int type);
        int getVdwType();
        
        double getVdwPotDepth();
        void setVdwPotDepth(double e);

        double getVdwAlpha();
        void setVdwAlpha(double e);
        
        void setVdwRmin(double r);
        double getVdwRmin();

        void setVdwAtomIndexA(int r);
        int  getVdwAtomIndexA();
        void setVdwAtomIndexB(int r);
        int  getVdwAtomIndexB();

        double getEnergy();
        void calcVdwGradient(double x1[], double x2[], int dim, double eps, double rmin, double alpha, int type);
        vector<double> getVdwGradientAtomTypeA();
        vector<double> getVdwGradientAtomTypeB();
        
        void setVdwAtomTypeA(char atype[]);
        void setVdwAtomTypeB(char atype[]);
        void getVdwAtomTypeA(char atype[]);
        void getVdwAtomTypeB(char atype[]);
        
    private:
        double epsilon;
        double Rmin;
        double Alpha;
        double e;
        vector<double> forceA;
        vector<double> forceB;
        char atomTypeA[4];
        char atomTypeB[4];
        int AtomIndexA, AtomIndexB;
        int vdwType;
    };
    
}

#endif /* defined(____VdwType__) */
