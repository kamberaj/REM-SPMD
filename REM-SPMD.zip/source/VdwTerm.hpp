//
//  VdwTerm.h
//  
//
//  Created by Hiqmet Kamberaj on 29/01/2016.
//
//

#ifndef ____VdwTerm__
#define ____VdwTerm__

#include <vector>

#include "VdwType.hpp"
#include "defs.hpp"


using namespace std;

namespace spo {
    class VdwTerm {
    public:
        VdwTerm();
        VdwTerm(int ndim, molStruct molecule, ffDefs _ff);
        VdwTerm(const VdwTerm& orig);
        virtual ~VdwTerm();
        
        vector <VdwType*> _vdwType;
        
        void calcEnergy(vector<double> X);
        vector<double> getForces();
        double getEnergy();
        double radiusRules(double ra, double rb);
        double epsilonRules(double ea, double eb);
        
    private:
        int Ndim;
        double vdwPot;
        vector<double> force;
    };
}
#endif /* defined(____VdwTerm__) */
