//
//  TorsionTerm.cpp
//  
//
//  Created by Hiqmet Kamberaj on 29/01/2016.
//
//

#include "TorsionTerm.hpp"

#include <iostream>
#include <cmath>
#include <vector>
#include "Maths.hpp"
#include "defs.hpp"


using namespace std;
using namespace maths;

namespace spo {
    TorsionTerm::TorsionTerm() {
    }
    TorsionTerm::TorsionTerm(int ndim, molStruct molecule, ffDefs _ffp) {
        double theta0;
        double kforce;
        double x1[3],x2[3],x3[3],x4[3];
        int I,J,K,L;
        this->Ndim = ndim;
        int natoms = ndim/3;
        for (int i=0; i < ndim; i++) {
            this->force.push_back(0.0);
        }
        for ( I = 0; I < natoms-3; I++ ) {
            J=I+1;
            K=J+1;
            L=K+1;
            x1[0] = molecule.pAtom[I].X;
            x1[1] = molecule.pAtom[I].Y;
            x1[2] = molecule.pAtom[I].Z;
            
            x2[0] = molecule.pAtom[J].X;
            x2[1] = molecule.pAtom[J].Y;
            x2[2] = molecule.pAtom[J].Z;
            
            x3[0] = molecule.pAtom[K].X;
            x3[1] = molecule.pAtom[K].Y;
            x3[2] = molecule.pAtom[K].Z;

            x4[0] = molecule.pAtom[L].X;
            x4[1] = molecule.pAtom[L].Y;
            x4[2] = molecule.pAtom[L].Z;

            kforce = 5.0 * torsunit * Unit_of_energy;
            theta0 = this->getTorsionAngle(x1, x2, x3, x4, 3);
            cout << I+1 << "  " << J+1 << "  " << K+1 << "  " << L+1 << endl;
            this->_TorsionType.push_back( new TorsionType(3, I, J, K, L, theta0, kforce) );
        }
    }
    TorsionTerm::TorsionTerm( const TorsionTerm& orig ){
    }
    TorsionTerm::~TorsionTerm(){
    }
    
    double TorsionTerm::getTorsionAngle(double x1[], double x2[], double x3[], double x4[], int dim){
        double F12[dim];
        double G23[dim];
        double H34[dim];
        double axb[dim];
        double bxc[dim];
        double ra2, rb2;
        double ra2r, rb2r, rabr;
        double ctheta;
        for (int i=0; i < dim; i++) {
            F12[i] = x1[i] - x2[i];
            G23[i] = x2[i] - x3[i];
            H34[i] = x4[i] - x3[i];
        }
        (void) _cross_product(F12, G23, axb);
        (void) _cross_product(G23, H34, bxc);
        ra2 = _dot_product(axb, axb);
        rb2 = _dot_product(bxc, bxc);
        ra2r = 1.0/ra2;
        rb2r = 1.0/rb2;
        rabr = sqrt( ra2r * rb2r );
        // Calculate cos(theta)
        ctheta = _dot_product(axb, bxc) * rabr;
        return acos( ctheta );
    }
    void TorsionTerm::calcEnergy(vector<double> X){
        int IA, IB, IC, ID;
        double xa[3], xb[3], xc[3], xd[3];
        vector<double> fa, fb, fc, fd;
        for (int i=0; i < 3; i++) {
            fa.push_back(0.0);
            fb.push_back(0.0);
            fc.push_back(0.0);
            fd.push_back(0.0);
        }
// Initialize to zero forces and pot
        this->TorsionPot = 0.0;
        for (int i = 0; i < this->Ndim; i++) this->force[i] = 0.0;
        
        for (std::vector<TorsionType*>::const_iterator it = _TorsionType.begin(); it != _TorsionType.end(); ++it) {
            IA = (*it)->getTorsionAtomIndexA();
            IB = (*it)->getTorsionAtomIndexB();
            IC = (*it)->getTorsionAtomIndexC();
            ID = (*it)->getTorsionAtomIndexD();
            for (int i=0; i < 3; i++){
                xa[i] = X[IA*3+i];
                xb[i] = X[IB*3+i];
                xc[i] = X[IC*3+i];
                xd[i] = X[ID*3+i];
            }
            (*it)->calcTorsionGradient(xa, xb, xc, xd, 3);
            fa = (*it)->getTorsionGradientAtomTypeA();
            fb = (*it)->getTorsionGradientAtomTypeB();
            fc = (*it)->getTorsionGradientAtomTypeC();
            fd = (*it)->getTorsionGradientAtomTypeD();
            for (int i=0; i < 3; i++){
                this->force[IA*3+i] += fa[i];
                this->force[IB*3+i] += fb[i];
                this->force[IC*3+i] += fc[i];
                this->force[ID*3+i] += fd[i];
            }
            this->TorsionPot += (*it)->getEnergy();
        }
    }
    vector<double> TorsionTerm::getForces(){
        return this->force;
    }
    double TorsionTerm::getEnergy(){
        return this->TorsionPot;
    }
 
}


