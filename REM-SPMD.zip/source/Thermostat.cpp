/* 
 * File:   Thermostat.cpp
 * Author: Hiqmet Kamberaj
 * 
 * Created on January, 2015
 */

#include "Thermostat.hpp"
#include "Nosethermo.hpp"
#include "Random.hpp"
#include "Maths.hpp"

#include <vector>
#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <cmath>

using namespace std;
using namespace rangen;
using namespace maths;


namespace thermo {

    Thermostat::Thermostat() {
    }

    Thermostat::Thermostat(int ndim, double kt, double tau, int m, int iParticle) {
        this->Ndim = ndim;
        this->setTemperature(kt);
        setThermostatParticle(iParticle);
        setupNoseChains(ndim, kt, tau, m);
    }

    Thermostat::Thermostat(const Thermostat& orig) {
    }

    Thermostat::~Thermostat() {
 
    }

    void Thermostat::refresh() {
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////
    void Thermostat::UpdateThermostatVariables(vector <double> &v, vector <double> mass, double dt){
        int idim = 0;
        double ke2, scale;
        for (std::vector<Nosethermo*>::const_iterator it = this->_Nose.begin(); it != this->_Nose.end(); ++it, ++idim) {
            ke2 = mass[idim] * v[idim] * v[idim];
            scale = (*it)->update_nhc_respa(ke2, dt);
            v[idim] *= scale;
        }
    }
    ////////////////////////////////////////////////////////////////////////////
    void Thermostat::setupNoseChains(int ndim, double kt, double tau, int m){
        for (int i = 0; i < ndim; ++i) {
             _Nose.push_back( new Nosethermo(kt, tau, m) );
        }
    }
    
    ///////////////////////////////////////////////////////////////////////////////////////////////////////
    void Thermostat::setTemperature(double kt){
        this->KT = kt;
    }
    double Thermostat::getTemperature(){
        return this->KT;
    }
    
    ////////////////////////////////////////////////////////////////////////////
    void Thermostat::setThermostatParticle(int i){
        this->myParticle = i;
    }
    int Thermostat::getThermostatParticle(){
        return this->myParticle;
    }

    ////////////////////////////////////////////////////////////////////////////
    void Thermostat::setThermostatDimension(int ndim){
        this->Ndim = ndim;
    }
    int Thermostat::getThermostatDimension(){
        return this->Ndim;
    }

    
    ////////////////////////////////////////////////////////////////////////////
    double Thermostat::getThermostatEnergy(){
        double ext=0;
        for (int k=0; k < this->Ndim; k++) {
            ext += _Nose[k]->getNoseEnergy();
        }
        return (ext);
    }
////////////////////////////////////////////////////////////////////////////
                
}

