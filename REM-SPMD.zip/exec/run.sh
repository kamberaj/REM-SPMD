dist/Debug/Mac/run1 -nreplicas 10 -nthermos 10 -nparticles 4 -niter 100 -nskip 1 -nstart 1 -nswaps 10 -tempi 20 -tempf 420 -qbias 1
